<?php
/**
 * VonCMS - Delete Page API
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

$input = json_decode(file_get_contents('php://input'), true);
$pageId = $input['id'] ?? null;

if (!$pageId || !is_numeric($pageId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Valid page ID is required']);
    exit();
}

try {
    if (!isset($pdo)) {
        echo json_encode(['success' => false, 'message' => 'Database not configured']);
        exit();
    }

    $stmt = $pdo->prepare("DELETE FROM pages WHERE id = :id");
    $stmt->execute(['id' => $pageId]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Page deleted', 'id' => (string)$pageId]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Page not found']);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to delete page: ' . $e->getMessage()]);
}
?>
