<?php
require_once '../von_config.php';

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

// Check if user is admin
if (strtolower($_SESSION['user']['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['user_id']) || !isset($input['role'])) {
    http_response_code(400);
    echo json_encode(['error' => 'User ID and Role required']);
    exit();
}

$userId = (int)$input['user_id'];
$role = $input['role'];

if (!in_array($role, ['admin', 'editor', 'user'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid role']);
    exit();
}

try {
    $stmt = $pdo->prepare("UPDATE users SET role = :role WHERE id = :id");
    $stmt->execute(['role' => $role, 'id' => $userId]);
    
    echo json_encode(['success' => true, 'message' => 'User role updated']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to update role']);
}
?>
