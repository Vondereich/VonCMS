<?php
/**
 * VonCMS - Email Verification API
 * Handles verification link clicks
 */

header("Access-Control-Allow-Origin: *");
header('Content-Type: text/html; charset=UTF-8');

require_once '../von_config.php';

// Get token from URL
$token = $_GET['token'] ?? '';

if (empty($token) || strlen($token) !== 64) {
    showResult(false, 'Invalid verification link.');
    exit();
}

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    showResult(false, 'Database not configured.');
    exit();
}

try {
    // Find user with this token
    $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE verification_token = ? AND email_verified = 0");
    $stmt->execute([$token]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        showResult(false, 'Invalid or expired verification link. The email may already be verified.');
        exit();
    }
    
    // Check token expiry (24 hours)
    $stmt = $pdo->prepare("SELECT verification_token_expires FROM users WHERE id = ?");
    $stmt->execute([$user['id']]);
    $expires = $stmt->fetchColumn();
    
    if ($expires && strtotime($expires) < time()) {
        showResult(false, 'Verification link has expired. Please request a new one.');
        exit();
    }
    
    // Mark email as verified
    $stmt = $pdo->prepare("UPDATE users SET email_verified = 1, verification_token = NULL, verification_token_expires = NULL WHERE id = ?");
    $stmt->execute([$user['id']]);
    
    showResult(true, 'Email verified successfully! You can now log in and participate in discussions.', $user['username']);
    
} catch (PDOException $e) {
    error_log("Email verification error: " . $e->getMessage());
    showResult(false, 'Verification failed. Please try again later.');
}

/**
 * Show styled result page
 */
function showResult($success, $message, $username = '') {
    $icon = $success ? '✅' : '❌';
    $color = $success ? '#10b981' : '#ef4444';
    $bgColor = $success ? '#ecfdf5' : '#fef2f2';
    $title = $success ? 'Email Verified!' : 'Verification Failed';
    
    echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>' . $title . ' - VonCMS</title>
        <style>
            * { box-sizing: border-box; }
            body { 
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                min-height: 100vh;
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 20px;
                margin: 0;
            }
            .card {
                background: white;
                border-radius: 16px;
                padding: 40px;
                max-width: 400px;
                text-align: center;
                box-shadow: 0 25px 50px rgba(0,0,0,0.25);
            }
            .icon { font-size: 64px; margin-bottom: 20px; }
            h1 { color: #1f2937; margin: 0 0 10px; font-size: 24px; }
            p { color: #6b7280; margin: 0 0 25px; line-height: 1.6; }
            .highlight { color: ' . $color . '; font-weight: bold; }
            .btn {
                display: inline-block;
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                color: white;
                padding: 14px 32px;
                border-radius: 8px;
                text-decoration: none;
                font-weight: bold;
                transition: transform 0.2s;
            }
            .btn:hover { transform: scale(1.05); }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="icon">' . $icon . '</div>
            <h1>' . $title . '</h1>
            <p>' . htmlspecialchars($message) . '</p>
            ' . ($success ? '<a href="/" class="btn">Go to Homepage</a>' : '<a href="/" class="btn">Back to Site</a>') . '
        </div>
    </body>
    </html>';
}
?>
