<?php
/**
 * VonCMS - Save Settings API (Database Version)
 * SECURITY: Admin-only access, validates input, prevents injection
 */

require_once '../von_config.php';
require_once '../security.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Enforce Security
SessionManager::requireValidSession();
CSRFProtection::requireToken();

// Check if user is admin (case-insensitive)
$userRole = strtolower($_SESSION['user']['role'] ?? '');
if (!isset($_SESSION['user']) || $userRole !== 'admin') {
    http_response_code(403);
    echo json_encode([
        'success' => false, 
        'error' => 'Admin access required'
    ]);
    exit();
}

$userId = $_SESSION['user']['id'] ?? null;

// Get input
$input = file_get_contents('php://input');
$settings = json_decode($input, true);

if (!$settings || !is_array($settings)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid settings data']);
    exit();
}

// Remove metadata fields
unset($settings['_source'], $settings['_access_level'], $settings['_warning']);

try {
    $pdo->beginTransaction();
    
    // Prepare UPSERT statement (INSERT or UPDATE if exists)
    // This ensures settings are created if they don't exist
    $upsertStmt = $pdo->prepare("
        INSERT INTO settings (setting_group, setting_key, setting_value, setting_type, is_public, updated_by, version)
        VALUES (?, ?, ?, ?, TRUE, ?, 1)
        ON DUPLICATE KEY UPDATE 
            setting_value = VALUES(setting_value),
            updated_by = VALUES(updated_by),
            version = version + 1,
            updated_at = NOW()
    ");
    
    $updated = 0;
    
    // Map settings to database structure
    $mappings = [
        // General
        ['siteName', 'general', 'site_name', 'string'],
        ['siteDescription', 'general', 'site_description', 'string'],
        ['siteTagline', 'general', 'site_tagline', 'string'],
        ['postsPerPage', 'general', 'posts_per_page', 'number'],
        ['maintenanceMode', 'general', 'maintenance_mode', 'boolean'],
        ['emailSmtp', 'general', 'email_smtp', 'string'],
        ['logoUrl', 'general', 'logo_url', 'string'],
        ['faviconUrl', 'general', 'favicon_url', 'string'],
        ['discussionEnabled', 'general', 'discussion_enabled', 'boolean'],
        ['permalinkStructure', 'general', 'permalink_structure', 'string'],
        ['domainUrl', 'general', 'domain_url', 'string'],
        ['timeZone', 'general', 'time_zone', 'string'],
        // SMTP Settings
        ['smtpHost', 'smtp', 'smtpHost', 'string'],
        ['smtpPort', 'smtp', 'smtpPort', 'number'],
        ['smtpUser', 'smtp', 'smtpUser', 'string'],
        ['smtpPass', 'smtp', 'smtpPass', 'string'],
        ['smtpEncryption', 'smtp', 'smtpEncryption', 'string'],
        ['smtpFromName', 'smtp', 'smtpFromName', 'string'],
        // Share Settings
        ['shareScript', 'share', 'shareScript', 'string'],
        ['sharePlacement', 'share', 'sharePlacement', 'string'],
    ];
    
    foreach ($mappings as $mapping) {
        list($jsonKey, $group, $dbKey, $type) = $mapping;
        
        if (isset($settings[$jsonKey])) {
            $value = $settings[$jsonKey];
            
            // Type conversion
            if ($type === 'boolean') {
                $value = $value ? 'true' : 'false';
            } elseif ($type === 'number') {
                $value = (string)$value;
            }
            
            // UPSERT: (group, key, value, type, is_public=TRUE implicit, user_id)
            $upsertStmt->execute([$group, $dbKey, $value, $type, $userId]);
            $updated++;
        }
    }
    
    // Complex objects (JSON)
    if (isset($settings['api'])) {
        $upsertStmt->execute(['seo', 'analytics', json_encode($settings['api']), 'json', $userId]);
        $updated++;
    }

    if (isset($settings['seo'])) {
        $upsertStmt->execute(['seo', 'site_config', json_encode($settings['seo']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['ads'])) {
        $upsertStmt->execute(['ads', 'configuration', json_encode($settings['ads']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['activeThemeId'])) {
        $upsertStmt->execute(['theme', 'active_theme_id', $settings['activeThemeId'], 'string', $userId]);
        $updated++;
    }
    
    if (isset($settings['theme'])) {
        $upsertStmt->execute(['theme', 'customization', json_encode($settings['theme']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['media'])) {
        $media = $settings['media'];
        if (isset($media['optimization'])) {
            $upsertStmt->execute(['media', 'optimization', json_encode($media['optimization']), 'json', $userId]);
            $updated++;
        }
        if (isset($media['sizes'])) {
            $upsertStmt->execute(['media', 'sizes', json_encode($media['sizes']), 'json', $userId]);
            $updated++;
        }
        if (isset($media['storage'])) {
            $upsertStmt->execute(['media', 'storage', json_encode($media['storage']), 'json', $userId]);
            $updated++;
        }
        if (isset($media['performance'])) {
            $upsertStmt->execute(['media', 'performance', json_encode($media['performance']), 'json', $userId]);
            $updated++;
        }
        if (isset($media['defaultView'])) {
            $upsertStmt->execute(['media', 'default_view', $media['defaultView'], 'string', $userId]);
            $updated++;
        }
    }
    
    if (isset($settings['navigation'])) {
        $upsertStmt->execute(['navigation', 'menu_items', json_encode($settings['navigation']), 'json', $userId]);
        $updated++;
    }

    if (isset($settings['shareTemplates'])) {
        $upsertStmt->execute(['share', 'templates', json_encode($settings['shareTemplates']), 'json', $userId]);
        $updated++;
    }
    
    
    if (isset($settings['sidebarLayout'])) {
        $upsertStmt->execute(['sidebar', 'layout', json_encode($settings['sidebarLayout']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['categories'])) {
        $upsertStmt->execute(['content', 'categories', json_encode($settings['categories']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['activePlugins'])) {
        $upsertStmt->execute(['plugins', 'active_plugins', json_encode($settings['activePlugins']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['customPlugins'])) {
        $upsertStmt->execute(['plugins', 'custom_plugins', json_encode($settings['customPlugins']), 'json', $userId]);
        $updated++;
    }
    
    if (isset($settings['pluginConfig'])) {
        $upsertStmt->execute(['plugins', 'plugin_config', json_encode($settings['pluginConfig']), 'json', $userId]);
        $updated++;
    }
    
    // Admin Profile (JSON object)
    if (isset($settings['adminProfile'])) {
        $upsertStmt->execute(['general', 'admin_profile', json_encode($settings['adminProfile']), 'json', $userId]);
        $updated++;
    }
    
    $pdo->commit();
    
    // Also update JSON file as backup (dual write for safety)
    $settingsFile = __DIR__ . '/../data/site_settings.json';
    $json = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    file_put_contents($settingsFile, $json);
    
    echo json_encode([
        'success' => true,
        'message' => 'Settings saved successfully',
        'updated' => $updated,
        'source' => 'database'
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
