<?php
/**
 * VonCMS AI Generate API
 * Proxies requests to Google Gemini API for content generation.
 * 
 * Frontend sends:
 *   - Header: x-gemini-key (API key)
 *   - Body: { topic: string, context?: string }
 * 
 * Returns:
 *   - { success: true, text: "generated HTML content" }
 *   - { success: false, error: "message" }
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, x-gemini-key');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Get API key from header
$apiKey = $_SERVER['HTTP_X_GEMINI_KEY'] ?? '';
if (empty($apiKey)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'API key required. Please provide your Gemini API key.']);
    exit();
}

// Get request body
$input = json_decode(file_get_contents('php://input'), true);
$topic = $input['topic'] ?? '';
$context = $input['context'] ?? '';

if (empty($topic)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Topic is required']);
    exit();
}

// Build prompt for blog content generation
$prompt = "You are a professional content writer. Write a well-structured blog post about: \"$topic\".";
if (!empty($context)) {
    $prompt .= " Additional context: $context";
}
$prompt .= "\n\nFormat the output as clean HTML with proper headings (h2, h3), paragraphs, and bullet points where appropriate. Do not include <html>, <head>, <body> tags - only the inner content. Make it engaging and SEO-friendly.";

// Gemini API endpoint (using gemini-1.5-flash for speed)
$geminiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=' . urlencode($apiKey);

$payload = [
    'contents' => [
        [
            'parts' => [
                ['text' => $prompt]
            ]
        ]
    ],
    'generationConfig' => [
        'temperature' => 0.7,
        'topK' => 40,
        'topP' => 0.95,
        'maxOutputTokens' => 2048,
    ]
];

// Make request to Gemini
$ch = curl_init($geminiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($payload),
    CURLOPT_TIMEOUT => 60,
    CURLOPT_SSL_VERIFYPEER => true
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlError = curl_error($ch);
curl_close($ch);

if ($curlError) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Network error: ' . $curlError]);
    exit();
}

if ($httpCode !== 200) {
    $errorData = json_decode($response, true);
    $errorMsg = $errorData['error']['message'] ?? 'Unknown API error';
    http_response_code($httpCode);
    echo json_encode(['success' => false, 'error' => 'Gemini API error: ' . $errorMsg]);
    exit();
}

$data = json_decode($response, true);

// Extract generated text
$generatedText = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';

if (empty($generatedText)) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'No content generated']);
    exit();
}

// Clean up the response - remove markdown code blocks if present
$generatedText = preg_replace('/^```html\s*/i', '', $generatedText);
$generatedText = preg_replace('/```\s*$/', '', $generatedText);
$generatedText = trim($generatedText);

echo json_encode(['success' => true, 'text' => $generatedText]);
?>
