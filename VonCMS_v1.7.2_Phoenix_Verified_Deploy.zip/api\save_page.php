<?php
require_once '../von_config.php';

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['title']) || !isset($input['slug'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Title and Slug are required']);
    exit();
}

// Sanitize input EXCEPT content and title (which may contain special chars)
if (function_exists('sanitize_input')) {
    $rawContent = $input['content'] ?? '';  // Preserve HTML content
    $rawTitle = $input['title'] ?? '';      // Preserve title with special chars
    $input = sanitize_input($input);
    $input['content'] = $rawContent;  // Restore unsanitized content
    $input['title'] = $rawTitle;      // Restore unsanitized title
}

try {
    if (!isset($pdo)) {
        echo json_encode(['success' => false, 'message' => 'Database not configured']);
        exit();
    }

    $pageId = $input['id'] ?? null;
    $isUpdate = $pageId && is_numeric($pageId);

    // Get meta description and keywords
    $metaDescription = $input['metaDescription'] ?? $input['meta_description'] ?? '';
    $keywords = $input['keywords'] ?? '';

    if ($isUpdate) {
        // Update existing page
        $stmt = $pdo->prepare("UPDATE pages SET 
            title = :title, 
            slug = :slug, 
            content = :content, 
            excerpt = :excerpt, 
            status = :status, 
            keywords = :keywords,
            meta_description = :meta_description,
            updated_at = NOW() 
        WHERE id = :id");
        $stmt->execute([
            'title' => $input['title'],
            'slug' => $input['slug'],
            'content' => $input['content'] ?? '',
            'excerpt' => $input['excerpt'] ?? '',
            'status' => $input['status'] ?? 'draft',
            'keywords' => $keywords,
            'meta_description' => $metaDescription,
            'id' => $pageId
        ]);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Page updated',
            'id' => (string)$pageId,
            'slug' => $input['slug']
        ]);
    } else {
        // Insert new page
        $stmt = $pdo->prepare("INSERT INTO pages (title, slug, content, excerpt, status, keywords, meta_description, author_id, created_at, updated_at) VALUES (:title, :slug, :content, :excerpt, :status, :keywords, :meta_description, :author_id, NOW(), NOW())");
        $stmt->execute([
            'title' => $input['title'],
            'slug' => $input['slug'],
            'content' => $input['content'] ?? '',
            'excerpt' => $input['excerpt'] ?? '',
            'status' => $input['status'] ?? 'draft',
            'keywords' => $keywords,
            'meta_description' => $metaDescription,
            'author_id' => 1
        ]);
        
        $newId = $pdo->lastInsertId();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Page created',
            'id' => (string)$newId,
            'slug' => $input['slug']
        ]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to save page: ' . $e->getMessage()]);
}
?>
