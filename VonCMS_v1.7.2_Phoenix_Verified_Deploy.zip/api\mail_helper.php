<?php
/**
 * VonCMS - Mail Helper
 * Simple SMTP email sending using PHPMailer or PHP mail()
 */

/**
 * Send email using SMTP settings from database or site_settings.json
 * Falls back to PHP mail() if SMTP not configured
 */
function vonSendMail($to, $subject, $htmlBody, $textBody = '') {
    // Try to load settings from database first
    $settings = loadSmtpSettings();
    
    $smtpHost = $settings['smtpHost'] ?? '';
    $smtpPort = $settings['smtpPort'] ?? 587;
    $smtpUser = $settings['smtpUser'] ?? '';
    $smtpPass = $settings['smtpPass'] ?? '';
    $smtpEncryption = $settings['smtpEncryption'] ?? 'tls';
    $smtpFromName = $settings['smtpFromName'] ?? 'VonCMS';
    $fromEmail = $smtpUser ?: 'noreply@' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    
    // If no SMTP configured, use PHP mail()
    if (empty($smtpHost) || empty($smtpUser)) {
        return sendWithPhpMail($to, $subject, $htmlBody, $fromEmail, $smtpFromName);
    }
    
    // Try SMTP with fsockopen (basic implementation without PHPMailer)
    return sendWithSmtp($to, $subject, $htmlBody, $textBody, [
        'host' => $smtpHost,
        'port' => $smtpPort,
        'user' => $smtpUser,
        'pass' => $smtpPass,
        'encryption' => $smtpEncryption,
        'fromEmail' => $fromEmail,
        'fromName' => $smtpFromName
    ]);
}

/**
 * Load SMTP settings from database or JSON file
 */
function loadSmtpSettings() {
    // Try database first
    try {
        $configFile = dirname(__DIR__) . '/von_config.php';
        if (file_exists($configFile)) {
            include_once $configFile;
            
            if (isset($pdo) && $pdo !== null) {
                // Check if settings table exists
                $tableCheck = $pdo->query("SHOW TABLES LIKE 'settings'");
                if ($tableCheck->rowCount() > 0) {
                    // Query SMTP settings from database
                    $stmt = $pdo->query("SELECT setting_key, setting_value FROM settings WHERE setting_group = 'smtp' OR setting_group = 'general'");
                    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    $settings = [];
                    foreach ($rows as $row) {
                        $key = $row['setting_key'];
                        $value = $row['setting_value'];
                        
                        // Map database keys to expected keys
                        switch ($key) {
                            case 'smtp_host':
                            case 'smtpHost':
                                $settings['smtpHost'] = $value;
                                break;
                            case 'smtp_port':
                            case 'smtpPort':
                                $settings['smtpPort'] = (int)$value;
                                break;
                            case 'smtp_user':
                            case 'smtpUser':
                                $settings['smtpUser'] = $value;
                                break;
                            case 'smtp_pass':
                            case 'smtpPass':
                                $settings['smtpPass'] = $value;
                                break;
                            case 'smtp_encryption':
                            case 'smtpEncryption':
                                $settings['smtpEncryption'] = $value;
                                break;
                            case 'smtp_from_name':
                            case 'smtpFromName':
                                $settings['smtpFromName'] = $value;
                                break;
                        }
                    }
                    
                    if (!empty($settings['smtpHost'])) {
                        return $settings;
                    }
                }
            }
        }
    } catch (Exception $e) {
        error_log("SMTP settings DB load failed: " . $e->getMessage());
    }
    
    // Fallback to JSON file
    $settingsPath = dirname(__DIR__) . '/data/site_settings.json';
    if (file_exists($settingsPath)) {
        $json = json_decode(file_get_contents($settingsPath), true);
        if ($json) {
            return $json;
        }
    }
    
    return [];
}

/**
 * Fallback: PHP mail() function
 */
function sendWithPhpMail($to, $subject, $htmlBody, $fromEmail, $fromName) {
    $headers = [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        'From: ' . $fromName . ' <' . $fromEmail . '>',
        'Reply-To: ' . $fromEmail,
        'X-Mailer: VonCMS'
    ];
    
    $result = @mail($to, $subject, $htmlBody, implode("\r\n", $headers));
    
    return [
        'success' => $result,
        'method' => 'php_mail',
        'message' => $result ? 'Email sent' : 'mail() function failed'
    ];
}

/**
 * SMTP sending using fsockopen (basic, no external library needed)
 */
function sendWithSmtp($to, $subject, $htmlBody, $textBody, $config) {
    $host = $config['host'];
    $port = $config['port'];
    $user = $config['user'];
    $pass = $config['pass'];
    $encryption = $config['encryption'];
    $fromEmail = $config['fromEmail'];
    $fromName = $config['fromName'];
    
    // For TLS/SSL connections
    $prefix = '';
    if ($encryption === 'ssl') {
        $prefix = 'ssl://';
    }
    
    // Connect to SMTP server
    $errno = 0;
    $errstr = '';
    $socket = @fsockopen($prefix . $host, $port, $errno, $errstr, 30);
    
    if (!$socket) {
        error_log("SMTP Connection failed: $errstr ($errno)");
        return ['success' => false, 'method' => 'smtp', 'message' => "Connection failed: $errstr"];
    }
    
    // Helper to send command and get response
    $sendCmd = function($cmd) use ($socket) {
        fwrite($socket, $cmd . "\r\n");
        return fgets($socket, 512);
    };
    
    $getResponse = function() use ($socket) {
        return fgets($socket, 512);
    };
    
    try {
        // Read greeting
        $getResponse();
        
        // EHLO
        $sendCmd("EHLO " . gethostname());
        // Read multi-line response
        while ($line = $getResponse()) {
            if (substr($line, 3, 1) === ' ') break;
        }
        
        // STARTTLS for TLS
        if ($encryption === 'tls') {
            $sendCmd("STARTTLS");
            $getResponse();
            stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $sendCmd("EHLO " . gethostname());
            while ($line = $getResponse()) {
                if (substr($line, 3, 1) === ' ') break;
            }
        }
        
        // AUTH LOGIN
        $sendCmd("AUTH LOGIN");
        $getResponse();
        $sendCmd(base64_encode($user));
        $getResponse();
        $sendCmd(base64_encode($pass));
        $authResponse = $getResponse();
        
        if (substr($authResponse, 0, 3) !== '235') {
            fclose($socket);
            return ['success' => false, 'method' => 'smtp', 'message' => 'Authentication failed'];
        }
        
        // MAIL FROM
        $sendCmd("MAIL FROM:<$fromEmail>");
        $getResponse();
        
        // RCPT TO
        $sendCmd("RCPT TO:<$to>");
        $getResponse();
        
        // DATA
        $sendCmd("DATA");
        $getResponse();
        
        // Email content
        $boundary = md5(uniqid(time()));
        $email = "From: $fromName <$fromEmail>\r\n";
        $email .= "To: $to\r\n";
        $email .= "Subject: $subject\r\n";
        $email .= "MIME-Version: 1.0\r\n";
        $email .= "Content-Type: text/html; charset=UTF-8\r\n";
        $email .= "\r\n";
        $email .= $htmlBody;
        $email .= "\r\n.\r\n";
        
        fwrite($socket, $email);
        $dataResponse = $getResponse();
        
        // QUIT
        $sendCmd("QUIT");
        fclose($socket);
        
        $success = substr($dataResponse, 0, 3) === '250';
        return [
            'success' => $success,
            'method' => 'smtp',
            'message' => $success ? 'Email sent via SMTP' : 'SMTP send failed'
        ];
        
    } catch (Exception $e) {
        @fclose($socket);
        error_log("SMTP Error: " . $e->getMessage());
        return ['success' => false, 'method' => 'smtp', 'message' => $e->getMessage()];
    }
}

/**
 * Generate email verification token
 */
function generateVerificationToken() {
    return bin2hex(random_bytes(32)); // 64 character token
}

/**
 * Send verification email to user
 */
function sendVerificationEmail($to, $username, $token) {
    // Build verification URL
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $basePath = dirname(dirname($_SERVER['REQUEST_URI'])); // Go up from /api/
    $verifyUrl = "$protocol://$host$basePath/api/verify_email.php?token=$token";
    
    $subject = "Verify Your Email - VonCMS";
    
    $htmlBody = '
    <!DOCTYPE html>
    <html>
    <head><meta charset="UTF-8"></head>
    <body style="font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px;">
        <div style="max-width: 500px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; text-align: center;">
                <h1 style="color: white; margin: 0; font-size: 24px;">📧 Verify Your Email</h1>
            </div>
            <div style="padding: 30px;">
                <p style="color: #333; font-size: 16px;">Hi <strong>' . htmlspecialchars($username) . '</strong>,</p>
                <p style="color: #666;">Thanks for registering! Please click the button below to verify your email address:</p>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="' . $verifyUrl . '" style="display: inline-block; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 15px 40px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">Verify Email</a>
                </div>
                <p style="color: #999; font-size: 12px;">Or copy this link: <br><a href="' . $verifyUrl . '" style="color: #667eea; word-break: break-all;">' . $verifyUrl . '</a></p>
                <hr style="border: none; border-top: 1px solid #eee; margin: 20px 0;">
                <p style="color: #999; font-size: 11px; text-align: center;">This link expires in 24 hours. If you didn\'t create an account, ignore this email.</p>
            </div>
        </div>
    </body>
    </html>';
    
    return vonSendMail($to, $subject, $htmlBody);
}
?>
