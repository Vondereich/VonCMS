<?php
/**
 * VonCMS - Generic Database Query Helper
 * Executes safe parameterized queries
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';

/**
 * Execute a SELECT query safely
 * @param string $table Table name
 * @param array $conditions WHERE conditions as key-value pairs
 * @param array $columns Columns to select (default: all)
 * @param int $limit Max rows to return
 * @return array Query results
 */
function dbSelect($table, $conditions = [], $columns = ['*'], $limit = 100) {
    global $pdo;
    
    $allowedTables = ['posts', 'pages', 'users', 'comments'];
    if (!in_array($table, $allowedTables)) {
        return ['error' => 'Invalid table'];
    }
    
    $cols = implode(', ', $columns);
    $sql = "SELECT $cols FROM $table";
    $params = [];
    
    if (!empty($conditions)) {
        $where = [];
        foreach ($conditions as $key => $value) {
            $where[] = "$key = ?";
            $params[] = $value;
        }
        $sql .= " WHERE " . implode(' AND ', $where);
    }
    
    $sql .= " LIMIT " . intval($limit);
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("dbSelect error: " . $e->getMessage());
        return ['error' => 'Query failed'];
    }
}

// If called directly via API
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['table'])) {
        echo json_encode(['success' => false, 'message' => 'Table required']);
        exit();
    }
    
    $result = dbSelect(
        $input['table'],
        $input['conditions'] ?? [],
        $input['columns'] ?? ['*'],
        $input['limit'] ?? 100
    );
    
    echo json_encode(['success' => true, 'data' => $result]);
} else {
    echo json_encode(['success' => false, 'message' => 'POST method required']);
}
?>
