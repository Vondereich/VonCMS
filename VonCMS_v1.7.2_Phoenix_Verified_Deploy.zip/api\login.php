<?php
/**
 * Login API with Rate Limiting and Session Management
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-CSRF-TOKEN");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';
require_once '../security.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check rate limiting FIRST
RateLimiter::requireNotLimited();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$username = $input['username'] ?? '';
$password = $input['password'] ?? '';
$honeypot = $input['hp_field'] ?? '';

// Honeypot check - bots will fill this hidden field
if (!empty($honeypot)) {
    // Log suspicious activity but don't reveal it's a honeypot
    error_log("Honeypot triggered from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Login failed']);
    exit();
}

if (empty($username) || empty($password)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Username and password required']);
    exit();
}

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    // No database - return error
    RateLimiter::recordAttempt();
    http_response_code(503);
    echo json_encode([
        'success' => false, 
        'message' => 'Database not configured. Please set up database connection in von_config.php'
    ]);
    exit();
}

try {
    // Authenticate against database
    $stmt = $pdo->prepare("SELECT id, username, email, role, avatar, bio, created_at AS createdAt, password FROM users WHERE email = ? OR username = ? LIMIT 1");
    $stmt->execute([$username, $username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password'])) {
        // Login success
        unset($user['password']); // Remove password from session
        
        $_SESSION['user'] = $user;
        
        // Generate CSRF token for this session
        $csrfToken = CSRFProtection::generateToken();
        
        // Reset rate limiter on successful login
        RateLimiter::reset();
        
        // Touch session timestamp
        SessionManager::touch();
        
        echo json_encode([
            'success' => true,
            'user' => $user,
            'csrf_token' => $csrfToken
        ]);
    } else {
        // Login failed - record attempt
        RateLimiter::recordAttempt();
        
        http_response_code(401);
        echo json_encode([
            'success' => false,
            'message' => 'Invalid credentials'
        ]);
    }
} catch (PDOException $e) {
    // Database error
    RateLimiter::recordAttempt();
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error. Please contact administrator.'
    ]);
}
?>
