<?php
/**
 * VonCMS - Media Sync Script
 * Scans uploads folder and syncs with database
 * Run once: http://yoursite.com/api/sync_media.php
 */
require_once '../von_config.php';

header('Content-Type: application/json');

$uploadsDir = dirname(__DIR__) . '/uploads/';
$allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'ico'];

$synced = 0;
$skipped = 0;
$errors = [];

function scanAndSync($dir, $pdo, $allowedExtensions, &$synced, &$skipped, &$errors) {
    if (!is_dir($dir)) return;
    
    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') continue;
        
        $fullPath = $dir . '/' . $item;
        
        if (is_dir($fullPath)) {
            scanAndSync($fullPath, $pdo, $allowedExtensions, $synced, $skipped, $errors);
        } else {
            $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
            if (in_array($ext, $allowedExtensions)) {
                // Get relative path from uploads folder
                $basePath = dirname(dirname($fullPath)) . '/';
                $relativePath = str_replace(dirname(__DIR__) . '/', '', $fullPath);
                
                // Check if already in database
                $stmt = $pdo->prepare("SELECT id FROM media WHERE filepath = ?");
                $stmt->execute([$relativePath]);
                
                if ($stmt->rowCount() > 0) {
                    $skipped++;
                    continue;
                }
                
                // Get file info
                $stat = stat($fullPath);
                $mimeType = mime_content_type($fullPath);
                
                // Insert into database
                try {
                    $stmt = $pdo->prepare("INSERT INTO media (filename, filepath, filetype, filesize, uploaded_by, uploaded_at) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $item,
                        $relativePath,
                        $mimeType,
                        $stat['size'],
                        1, // Default to admin user
                        date('Y-m-d H:i:s', $stat['mtime'])
                    ]);
                    $synced++;
                } catch (PDOException $e) {
                    $errors[] = "Failed to insert $item: " . $e->getMessage();
                }
            }
        }
    }
}

try {
    scanAndSync($uploadsDir, $pdo, $allowedExtensions, $synced, $skipped, $errors);
    
    echo json_encode([
        'success' => true,
        'message' => "Sync complete!",
        'synced' => $synced,
        'skipped' => $skipped,
        'errors' => $errors
    ], JSON_PRETTY_PRINT);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>
