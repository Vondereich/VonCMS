<?php
/**
 * VonCMS - Save Comments API
 * Saves comments to database
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit();
}

require_once '../von_config.php';
require_once '../security.php';

// Get input data FIRST (before CSRF checks that use $input)
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid JSON input']);
    exit();
}

// Enforce Security for Moderation Actions
if (isset($input['action']) && in_array($input['action'], ['delete', 'updateStatus', 'like'])) {
    SessionManager::requireValidSession();
    CSRFProtection::requireToken();
}

// For 'add', we check CSRF but might allow guest sessions depending on setup
if (isset($input['action']) && $input['action'] === 'add') {
    CSRFProtection::requireToken();
}

// Check database connection
if (!isset($pdo) || $pdo === null) {
    // Fallback to JSON storage
    $dataDir = __DIR__ . '/../data';
    $commentsFile = $dataDir . '/comments.json';
    
    if (!is_dir($dataDir)) {
        mkdir($dataDir, 0755, true);
    }
    
    $comments = isset($input['comments']) ? $input['comments'] : $input;
    $data = ['comments' => $comments];
    $result = file_put_contents($commentsFile, json_encode($data, JSON_PRETTY_PRINT));
    
    if ($result === false) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Failed to save comments']);
        exit();
    }
    
    echo json_encode(['success' => true, 'message' => 'Comments saved to JSON', 'source' => 'json']);
    exit();
}

try {
    // Handle single comment add
    if (isset($input['action']) && $input['action'] === 'add') {
        $postId = isset($input['postId']) ? intval(preg_replace('/[^0-9]/', '', $input['postId'])) : 0;
        $userId = isset($input['userId']) ? $input['userId'] : null;
        
        // Flexible parentId handling (strips 'c-' or 'r-' prefixes)
        $parentIdRaw = isset($input['parentId']) ? $input['parentId'] : null;
        $parentId = $parentIdRaw ? intval(preg_replace('/[^0-9]/', '', $parentIdRaw)) : null;
        $username = isset($input['username']) ? htmlspecialchars($input['username'], ENT_QUOTES, 'UTF-8') : 'Anonymous';
        $userAvatar = isset($input['userAvatar']) ? $input['userAvatar'] : null;
        $content = isset($input['content']) ? htmlspecialchars($input['content'], ENT_QUOTES, 'UTF-8') : '';
        
        if (empty($content)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Comment content is required']);
            exit();
        }
        
        // ============================================
        // AUTO SPAM DETECTION SYSTEM
        // ============================================
        $status = 'approved'; // Default
        $spamReasons = [];
        
        // 1. Honeypot Check (if field exists and is filled = bot)
        $honeypot = $input['hp_field'] ?? $input['website'] ?? '';
        if (!empty($honeypot)) {
            $status = 'spam';
            $spamReasons[] = 'honeypot';
            error_log("Comment spam (honeypot): IP " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
        }
        
        // 2. Spam Keywords Check (from settings or default)
        $defaultKeywords = 'viagra, cialis, casino, lottery, prize winner, click here, buy now, free money, make money fast, earn extra cash, work from home, crypto investment, bitcoin profit, forex trading, adult content, xxx, nigerian prince, wire transfer, western union';
        $keywordsString = $defaultKeywords;
        
        // Try to get from database settings
        try {
            $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'spamKeywords' LIMIT 1");
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row && !empty($row['setting_value'])) {
                $keywordsString = $row['setting_value'];
            }
        } catch (Exception $e) {
            // Use default on error
        }
        
        $spamKeywords = array_map('trim', explode(',', strtolower($keywordsString)));
        $contentLower = strtolower($content);
        foreach ($spamKeywords as $keyword) {
            if (strpos($contentLower, $keyword) !== false) {
                $status = 'pending'; // Not spam, but needs review
                $spamReasons[] = "keyword:$keyword";
                break;
            }
        }
        
        // 3. Link Density Check (more than 2 links = suspicious)
        $linkCount = preg_match_all('/(https?:\/\/|www\.)/i', $content);
        if ($linkCount > 2) {
            $status = 'pending';
            $spamReasons[] = "links:$linkCount";
        }
        
        // 4. All Caps Check (more than 50% caps = suspicious)
        $upperCount = preg_match_all('/[A-Z]/', $content);
        $letterCount = preg_match_all('/[a-zA-Z]/', $content);
        if ($letterCount > 10 && ($upperCount / $letterCount) > 0.5) {
            $status = 'pending';
            $spamReasons[] = 'allcaps';
        }
        
        // Log spam detection
        if (!empty($spamReasons)) {
            error_log("Comment flagged ($status): " . implode(', ', $spamReasons));
        }
        // ============================================
        
        $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, parent_id, user_name, user_avatar, content, likes, status, created_at) 
                               VALUES (?, ?, ?, ?, ?, ?, 0, ?, NOW())");
        $stmt->execute([$postId, $userId, $parentId, $username, $userAvatar, $content, $status]);
        
        $newId = $pdo->lastInsertId();
        $prefix = $parentId ? 'r-' : 'c-';
        
        echo json_encode([
            'success' => true, 
            'message' => $status === 'approved' ? 'Comment added' : 'Comment submitted for review',
            'id' => $prefix . $newId,
            'status' => $status,
            'source' => 'database'
        ]);
        exit();
    }
    
    // Handle like/unlike
    if (isset($input['action']) && $input['action'] === 'like') {
        $commentId = isset($input['commentId']) ? intval(preg_replace('/[^0-9]/', '', $input['commentId'])) : 0;
        $delta = isset($input['delta']) ? intval($input['delta']) : 1;
        
        $stmt = $pdo->prepare("UPDATE comments SET likes = GREATEST(0, likes + ?) WHERE id = ?");
        $stmt->execute([$delta, $commentId]);
        
        echo json_encode(['success' => true, 'message' => 'Like updated', 'source' => 'database']);
        exit();
    }
    
    // Handle delete
    if (isset($input['action']) && $input['action'] === 'delete') {
        $commentId = isset($input['commentId']) ? intval(preg_replace('/[^0-9]/', '', $input['commentId'])) : 0;
        
        // Delete replies first
        $pdo->prepare("DELETE FROM comments WHERE parent_id = ?")->execute([$commentId]);
        // Delete comment
        $pdo->prepare("DELETE FROM comments WHERE id = ?")->execute([$commentId]);
        
        echo json_encode(['success' => true, 'message' => 'Comment deleted', 'source' => 'database']);
        exit();
    }
    
    // Handle status update
    if (isset($input['action']) && $input['action'] === 'updateStatus') {
        $commentId = isset($input['commentId']) ? intval(preg_replace('/[^0-9]/', '', $input['commentId'])) : 0;
        $status = isset($input['status']) ? $input['status'] : 'approved';
        
        if (!in_array($status, ['approved', 'pending', 'spam'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid status']);
            exit();
        }
        
        $stmt = $pdo->prepare("UPDATE comments SET status = ? WHERE id = ?");
        $stmt->execute([$status, $commentId]);
        
        echo json_encode(['success' => true, 'message' => 'Status updated', 'source' => 'database']);
        exit();
    }
    
    // Legacy: Bulk save all comments (for migration from JSON)
    if (isset($input['comments']) && is_array($input['comments'])) {
        $count = 0;
        foreach ($input['comments'] as $comment) {
            $postId = isset($comment['postId']) ? intval(preg_replace('/[^0-9]/', '', $comment['postId'])) : 0;
            $userId = isset($comment['userId']) ? $comment['userId'] : null;
            $username = isset($comment['username']) ? htmlspecialchars($comment['username'], ENT_QUOTES, 'UTF-8') : 'Anonymous';
            $userAvatar = isset($comment['userAvatar']) ? $comment['userAvatar'] : null;
            $content = isset($comment['content']) ? htmlspecialchars($comment['content'], ENT_QUOTES, 'UTF-8') : '';
            $likes = isset($comment['likes']) ? intval($comment['likes']) : 0;
            $createdAt = isset($comment['createdAt']) ? $comment['createdAt'] : date('Y-m-d H:i:s');
            
            $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, user_name, user_avatar, content, likes, status, created_at) 
                                   VALUES (?, ?, ?, ?, ?, ?, 'approved', ?)");
            $stmt->execute([$postId, $userId, $username, $userAvatar, $content, $likes, $createdAt]);
            $count++;
            
            // Handle replies
            if (isset($comment['replies']) && is_array($comment['replies'])) {
                $parentId = $pdo->lastInsertId();
                foreach ($comment['replies'] as $reply) {
                    $rPostId = isset($reply['postId']) ? intval(preg_replace('/[^0-9]/', '', $reply['postId'])) : $postId;
                    $rUserId = isset($reply['userId']) ? $reply['userId'] : null;
                    $rUsername = isset($reply['username']) ? htmlspecialchars($reply['username'], ENT_QUOTES, 'UTF-8') : 'Anonymous';
                    $rUserAvatar = isset($reply['userAvatar']) ? $reply['userAvatar'] : null;
                    $rContent = isset($reply['content']) ? htmlspecialchars($reply['content'], ENT_QUOTES, 'UTF-8') : '';
                    $rLikes = isset($reply['likes']) ? intval($reply['likes']) : 0;
                    $rCreatedAt = isset($reply['createdAt']) ? $reply['createdAt'] : date('Y-m-d H:i:s');
                    
                    $stmt = $pdo->prepare("INSERT INTO comments (post_id, user_id, parent_id, user_name, user_avatar, content, likes, status, created_at) 
                                           VALUES (?, ?, ?, ?, ?, ?, ?, 'approved', ?)");
                    $stmt->execute([$rPostId, $rUserId, $parentId, $rUsername, $rUserAvatar, $rContent, $rLikes, $rCreatedAt]);
                    $count++;
                }
            }
        }
        
        echo json_encode(['success' => true, 'message' => "Migrated $count comments to database", 'source' => 'database']);
        exit();
    }
    
    echo json_encode(['success' => false, 'message' => 'Unknown action or invalid input']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
