<?php
/**
 * VonCMS - Track Visitor API
 * Records page visits for analytics
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    echo json_encode(['success' => false, 'message' => 'Database not configured']);
    exit();
}

// Auto-migration: Create analytics table if not exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS analytics (
        id INT AUTO_INCREMENT PRIMARY KEY,
        page_url VARCHAR(500),
        referrer VARCHAR(500),
        user_agent TEXT,
        ip_hash VARCHAR(64),
        visit_date DATE,
        visit_time TIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_date (visit_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
} catch (PDOException $e) {
    error_log("Analytics table creation: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Record a visit
    $input = json_decode(file_get_contents('php://input'), true);
    $pageUrl = $input['url'] ?? $_SERVER['REQUEST_URI'] ?? '';
    $referrer = $input['referrer'] ?? $_SERVER['HTTP_REFERER'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    // Hash IP for privacy
    $ipHash = hash('sha256', ($_SERVER['REMOTE_ADDR'] ?? '') . date('Y-m'));
    
    try {
        $stmt = $pdo->prepare("INSERT INTO analytics (page_url, referrer, user_agent, ip_hash, visit_date, visit_time) VALUES (?, ?, ?, ?, CURDATE(), CURTIME())");
        $stmt->execute([$pageUrl, $referrer, $userAgent, $ipHash]);
        
        echo json_encode(['success' => true, 'message' => 'Visit recorded']);
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    
} else {
    // GET: Return analytics data for dashboard
    $days = intval($_GET['days'] ?? 7);
    $days = min($days, 90); // Max 90 days
    
    try {
        // Get visits per day for last N days
        $stmt = $pdo->prepare("
            SELECT visit_date, COUNT(*) as visits, COUNT(DISTINCT ip_hash) as unique_visitors
            FROM analytics 
            WHERE visit_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            GROUP BY visit_date
            ORDER BY visit_date ASC
        ");
        $stmt->execute([$days]);
        $dailyStats = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Get total stats
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(*) as total_views,
                COUNT(DISTINCT ip_hash) as unique_visitors,
                COUNT(DISTINCT page_url) as pages_viewed
            FROM analytics 
            WHERE visit_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
        ");
        $stmt->execute([$days]);
        $totals = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Get top pages
        $stmt = $pdo->prepare("
            SELECT page_url, COUNT(*) as views 
            FROM analytics 
            WHERE visit_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            GROUP BY page_url
            ORDER BY views DESC
            LIMIT 10
        ");
        $stmt->execute([$days]);
        $topPages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'analytics' => [
                'daily' => $dailyStats,
                'totals' => $totals,
                'topPages' => $topPages,
                'period' => $days . ' days'
            ]
        ]);
        
    } catch (PDOException $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>
