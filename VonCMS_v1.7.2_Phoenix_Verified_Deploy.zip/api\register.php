<?php
/**
 * VonCMS - User Registration API
 * Handles new user registration with spam protection
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-CSRF-TOKEN");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';
require_once '../security.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check rate limiting
RateLimiter::requireNotLimited();

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$username = trim($input['username'] ?? '');
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';
$confirmPassword = $input['confirmPassword'] ?? '';
$honeypot = $input['hp_field'] ?? '';

// Honeypot check
if (!empty($honeypot)) {
    error_log("Honeypot triggered during registration from IP: " . ($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Registration failed']);
    exit();
}

// Validation
$errors = [];

if (empty($username) || strlen($username) < 3) {
    $errors[] = 'Username must be at least 3 characters';
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Please enter a valid email address';
}

if (strlen($password) < 8) {
    $errors[] = 'Password must be at least 8 characters';
}

if (!preg_match('/[A-Z]/', $password)) {
    $errors[] = 'Password must contain at least 1 uppercase letter';
}

if (!preg_match('/[0-9]/', $password)) {
    $errors[] = 'Password must contain at least 1 number';
}

if (!preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
    $errors[] = 'Password must contain at least 1 special character';
}

if ($password !== $confirmPassword) {
    $errors[] = 'Passwords do not match';
}

// Check for special characters in username
if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    $errors[] = 'Username can only contain letters, numbers, and underscores';
}

if (!empty($errors)) {
    RateLimiter::recordAttempt();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => implode('. ', $errors)]);
    exit();
}

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    http_response_code(503);
    echo json_encode([
        'success' => false, 
        'message' => 'Database not configured. Please complete installation first.'
    ]);
    exit();
}

// Auto-migration: Add email verification columns if not exist
try {
    $columns = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    
    if (!in_array('email_verified', $columns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN email_verified TINYINT(1) DEFAULT 0");
    }
    if (!in_array('verification_token', $columns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN verification_token VARCHAR(64) DEFAULT NULL");
    }
    if (!in_array('verification_token_expires', $columns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN verification_token_expires DATETIME DEFAULT NULL");
    }
} catch (PDOException $e) {
    error_log("Migration check: " . $e->getMessage());
}

try {
    // Check if username already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    
    if ($stmt->fetch()) {
        RateLimiter::recordAttempt();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Username or email already taken']);
        exit();
    }
    
    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    
    // Generate unique ID and verification token
    $userId = 'user_' . bin2hex(random_bytes(8));
    
    // Include mail helper
    require_once 'mail_helper.php';
    $verificationToken = generateVerificationToken();
    $tokenExpires = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    // Insert new user (email_verified = 0)
    $stmt = $pdo->prepare("INSERT INTO users (id, username, email, password, role, email_verified, verification_token, verification_token_expires, created_at) VALUES (?, ?, ?, ?, 'Member', 0, ?, ?, NOW())");
    $stmt->execute([$userId, $username, $email, $hashedPassword, $verificationToken, $tokenExpires]);
    
    // Send verification email
    $emailResult = sendVerificationEmail($email, $username, $verificationToken);
    
    // Create user object for response
    $user = [
        'id' => $userId,
        'username' => $username,
        'email' => $email,
        'role' => 'Member',
        'avatar' => '',
        'bio' => '',
        'email_verified' => false,
        'createdAt' => date('Y-m-d H:i:s')
    ];
    
    // Store in session (limited access until verified)
    $_SESSION['user'] = $user;
    SessionManager::touch();
    
    // Return success with verification message
    $message = 'Registration successful! ';
    if ($emailResult['success']) {
        $message .= 'Please check your email to verify your account.';
    } else {
        $message .= 'Welcome! (Email verification skipped - SMTP not configured)';
        // If SMTP not configured, auto-verify
        $stmt = $pdo->prepare("UPDATE users SET email_verified = 1 WHERE id = ?");
        $stmt->execute([$userId]);
        $user['email_verified'] = true;
        $_SESSION['user']['email_verified'] = true;
    }
    
    echo json_encode([
        'success' => true,
        'message' => $message,
        'user' => $user,
        'emailSent' => $emailResult['success']
    ]);
    
} catch (PDOException $e) {
    error_log("Registration error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Registration failed. Please try again later.']);
}
?>
