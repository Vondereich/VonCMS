<?php
/**
 * VonCMS - Get Posts API
 * Returns all posts from the database
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

try {
    // Check if database connection exists
    if (!isset($pdo)) {
        // Return empty array if no database configured (dev mode)
        echo json_encode([]);
        exit();
    }

    // Query all posts with author username
    $stmt = $pdo->query("SELECT 
        p.id,
        p.title,
        p.slug,
        p.content,
        p.excerpt,
        p.status,
        p.image_url,
        p.keywords,
        p.category,
        p.meta_description,
        p.author_id,
        p.created_at,
        p.updated_at,
        u.username AS author_name
    FROM posts p
    LEFT JOIN users u ON p.author_id = u.id
    ORDER BY p.created_at DESC");
    
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Transform for frontend compatibility
    $result = array_map(function($post) {
        return [
            'id' => (string)$post['id'],
            'title' => $post['title'],
            'slug' => $post['slug'] ?? '',
            'content' => $post['content'] ?? '',
            'excerpt' => $post['excerpt'] ?? '',
            'status' => $post['status'] ?? 'draft',
            'category' => $post['category'] ?? 'Uncategorized',
            'image' => $post['image_url'] ?? '',
            'keywords' => $post['keywords'] ?? '',
            'metaDescription' => $post['meta_description'] ?? '',
            'author' => $post['author_name'] ?? 'Unknown',
            'authorId' => $post['author_id'] ?? null,
            'updatedAt' => $post['updated_at'] ?? $post['created_at'] ?? date('Y-m-d H:i:s'),
            'readTime' => ceil(str_word_count(strip_tags($post['content'] ?? '')) / 200) . ' min read'
        ];
    }, $posts);
    
    echo json_encode($result);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
?>
