<?php
require_once '../von_config.php';

// Check Auth (Admin only)
// if (!check_auth() || !is_admin()) { ... }

try {
    $stmt = $pdo->query("SELECT id, username, email, role, avatar, bio, created_at AS createdAt FROM users");
    $users = $stmt->fetchAll();
    echo json_encode($users);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to fetch users']);
}
?>
