<?php
/**
 * VonCMS - Get Storage Usage API
 * Returns disk usage of /uploads/ folder
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

/**
 * Calculate folder size recursively
 */
function getFolderSize($dir) {
    $size = 0;
    if (is_dir($dir)) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($dir, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            $size += $file->getSize();
        }
    }
    return $size;
}

/**
 * Format bytes to human readable
 */
function formatBytes($bytes, $precision = 2) {
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $bytes = max($bytes, 0);
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
    $pow = min($pow, count($units) - 1);
    $bytes /= pow(1024, $pow);
    return round($bytes, $precision) . ' ' . $units[$pow];
}

// Calculate storage
$uploadsPath = dirname(__DIR__) . '/uploads';

// Get used space
$usedBytes = getFolderSize($uploadsPath);
$usedFormatted = formatBytes($usedBytes);

// Get total disk space (or use configurable limit)
// Default limit: 1GB for shared hosting
$limitBytes = 1 * 1024 * 1024 * 1024; // 1GB

// Try to get actual disk space on the partition
$totalDisk = @disk_total_space($uploadsPath);
$freeDisk = @disk_free_space($uploadsPath);

if ($totalDisk && $totalDisk > 0) {
    // Use actual disk space but cap at 10GB for display
    $limitBytes = min($totalDisk, 10 * 1024 * 1024 * 1024);
}

// Calculate percentage
$percentage = ($limitBytes > 0) ? round(($usedBytes / $limitBytes) * 100, 1) : 0;

// Count files
$fileCount = 0;
if (is_dir($uploadsPath)) {
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($uploadsPath, RecursiveDirectoryIterator::SKIP_DOTS)
    );
    foreach ($iterator as $file) {
        if ($file->isFile()) {
            $fileCount++;
        }
    }
}

echo json_encode([
    'success' => true,
    'storage' => [
        'used' => $usedFormatted,
        'usedBytes' => $usedBytes,
        'limit' => formatBytes($limitBytes),
        'limitBytes' => $limitBytes,
        'percentage' => $percentage,
        'fileCount' => $fileCount,
        'diskTotal' => $totalDisk ? formatBytes($totalDisk) : null,
        'diskFree' => $freeDisk ? formatBytes($freeDisk) : null
    ]
]);
?>
