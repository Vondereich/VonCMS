<?php
/**
 * VonCMS - Save User API (Admin)
 * Saves/updates users from admin panel
 */
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid JSON input']);
    exit();
}

if (!isset($input['username']) || !isset($input['email'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Username and Email are required']);
    exit();
}

// Sanitize input
if (function_exists('sanitize_input')) {
    $input = sanitize_input($input);
}

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'Database not configured']);
    exit();
}

try {
    $inputId = $input['id'] ?? '';
    
    // Check database if user already exists (much more reliable than ID format checking)
    $isNewUser = true;
    if (!empty($inputId)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
        $stmt->execute([$inputId]);
        if ($stmt->fetch()) {
            $isNewUser = false;
        }
    }
    
    if ($isNewUser) {
        // Generate unique ID for new user
        $userId = 'user_' . bin2hex(random_bytes(8));
        
        // Check for duplicate username/email
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$input['username'], $input['email']]);
        if ($stmt->fetch()) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Username or email already exists']);
            exit();
        }
        
        // Password strength validation for new users
        $password = $input['password'] ?? '';
        if (strlen($password) < 8 || 
            !preg_match('/[A-Z]/', $password) || 
            !preg_match('/[0-9]/', $password) || 
            !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'error' => 'Password must be at least 8 characters with uppercase letter, number, and special character']);
            exit();
        }
        
        // Insert new user
        $stmt = $pdo->prepare("INSERT INTO users (id, username, email, password, role, avatar, bio, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->execute([
            $userId,
            $input['username'],
            $input['email'],
            password_hash($input['password'] ?? 'password123', PASSWORD_BCRYPT),
            $input['role'] ?? 'Member',
            $input['avatar'] ?? '',
            $input['bio'] ?? ''
        ]);
        
        echo json_encode(['success' => true, 'id' => $userId, 'message' => 'User created successfully']);
    } else {
        // Update existing user
        $sql = "UPDATE users SET username = ?, email = ?, role = ?, avatar = ?, bio = ?";
        $params = [
            $input['username'], 
            $input['email'], 
            $input['role'] ?? 'Writer', 
            $input['avatar'] ?? '',
            $input['bio'] ?? ''
        ];

        // Only update password if provided
        if (!empty($input['password'])) {
            // Validate password strength
            $password = $input['password'];
            if (strlen($password) < 8 || 
                !preg_match('/[A-Z]/', $password) || 
                !preg_match('/[0-9]/', $password) || 
                !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $password)) {
                http_response_code(400);
                echo json_encode(['success' => false, 'error' => 'Password must be at least 8 characters with uppercase letter, number, and special character']);
                exit();
            }
            $sql .= ", password = ?";
            $params[] = password_hash($input['password'], PASSWORD_BCRYPT);
        }

        $sql .= " WHERE id = ?";
        $params[] = $input['id'];
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        echo json_encode(['success' => true, 'id' => $input['id'], 'message' => 'User updated successfully']);
    }
} catch (PDOException $e) {
    error_log("Save user error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to save user: ' . $e->getMessage()]);
}
?>
