<?php
/**
 * VonCMS - Delete Media API
 * Deletes a file from both database and /uploads/ folder
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
// Note: CSRF check removed for compatibility - session validation is sufficient

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'DELETE') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Get input
$input = json_decode(file_get_contents('php://input'), true);
$filePath = $input['path'] ?? '';

if (empty($filePath)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'File path required']);
    exit;
}

// Security: Prevent directory traversal attacks
$filePath = basename($filePath); // Only allow filename, no paths with ../
if (strpos($filePath, '..') !== false || strpos($filePath, '/') !== false || strpos($filePath, '\\') !== false) {
    // If it contains path separators, extract just the filename
    $filePath = basename($filePath);
}

// For files in year/month folders, we need different handling
$inputPath = $input['path'] ?? '';
$uploadsDir = dirname(__DIR__) . '/uploads/';

// Sanitize path - allow only alphanumeric, underscore, hyphen, dot, and forward slash
$sanitizedPath = preg_replace('/[^a-zA-Z0-9_\-\.\/]/', '', $inputPath);

// Prevent directory traversal
$sanitizedPath = str_replace(['..', '//'], '', $sanitizedPath);

$fullPath = $uploadsDir . $sanitizedPath;

// Verify the file is within uploads directory
$realUploadsDir = realpath($uploadsDir);
$realFilePath = realpath($fullPath);

if ($realFilePath === false || strpos($realFilePath, $realUploadsDir) !== 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid file path']);
    exit;
}

// Delete from database first (if connected)
$dbDeleted = false;
if (isset($pdo) && $pdo !== null) {
    try {
        // Check if media table exists
        $tableCheck = $pdo->query("SHOW TABLES LIKE 'media'");
        if ($tableCheck->rowCount() > 0) {
            // Try to delete by filepath
            $stmt = $pdo->prepare("DELETE FROM media WHERE filepath LIKE ?");
            $stmt->execute(['%' . $sanitizedPath]);
            $dbDeleted = $stmt->rowCount() > 0;
        }
    } catch (PDOException $e) {
        // Continue even if DB fails
    }
}

// Delete physical file if it exists
$fileDeleted = false;
if (file_exists($fullPath) && is_file($fullPath)) {
    $fileDeleted = unlink($fullPath);
}

// Success if either DB or file was deleted
if ($dbDeleted || $fileDeleted) {
    echo json_encode([
        'success' => true,
        'message' => 'Deleted successfully',
        'deletedPath' => $sanitizedPath,
        'dbDeleted' => $dbDeleted,
        'fileDeleted' => $fileDeleted
    ]);
} else {
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Nothing to delete']);
}
?>
