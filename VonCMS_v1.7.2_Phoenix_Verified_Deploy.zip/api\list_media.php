<?php
/**
 * VonCMS - List Media API
 * Returns media files from database with filesystem fallback
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

/**
 * Format file size to human readable
 */
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

// Base URL for uploaded files
// Auto-detect base URL
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
// If script_name is /VonCMS/api/list_media.php, dirname is /VonCMS/api
// We want /VonCMS/uploads/
$baseUrl = dirname($scriptDir) . '/uploads/';
// Fix backslashes on Windows
$baseUrl = str_replace('\\', '/', $baseUrl);
$uploadsDir = dirname(__DIR__) . '/uploads/';

// Create uploads directory if it doesn't exist
if (!is_dir($uploadsDir)) {
    mkdir($uploadsDir, 0755, true);
}

$files = [];
$source = 'database';

// Try to get files from database first
if (isset($pdo) && $pdo !== null) {
    try {
        // Check if media table exists
        $tableCheck = $pdo->query("SHOW TABLES LIKE 'media'");
        if ($tableCheck->rowCount() > 0) {
            $stmt = $pdo->query("SELECT id, filename, filepath, filetype, filesize, uploaded_by, uploaded_at FROM media ORDER BY uploaded_at DESC");
            $mediaRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach ($mediaRows as $row) {
                $ext = strtolower(pathinfo($row['filename'], PATHINFO_EXTENSION));
                $files[] = [
                    'id' => (string)$row['id'],
                    'name' => $row['filename'],
                    'path' => str_replace('uploads/', '', $row['filepath']),
                    'url' => $baseUrl . str_replace('uploads/', '', $row['filepath']),
                    'type' => 'image',
                    'size' => formatFileSize($row['filesize'] ?? 0),
                    'sizeBytes' => (int)($row['filesize'] ?? 0),
                    'uploadedAt' => $row['uploaded_at'] ? date('Y-m-d', strtotime($row['uploaded_at'])) : date('Y-m-d'),
                    'extension' => $ext,
                    'uploadedBy' => $row['uploaded_by']
                ];
            }
        }
    } catch (PDOException $e) {
        // Fall through to filesystem scan
        $source = 'filesystem';
    }
}

// Fallback: Scan filesystem if database is empty or unavailable
if (empty($files)) {
    $source = 'filesystem';
    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'ico'];
    
    function scanDirectory($dir, $baseUrl, $allowedExtensions, &$files) {
        if (!is_dir($dir)) return;
        
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            
            $fullPath = $dir . '/' . $item;
            $relativePath = str_replace(dirname(__DIR__) . '/uploads/', '', $fullPath);
            
            if (is_dir($fullPath)) {
                scanDirectory($fullPath, $baseUrl, $allowedExtensions, $files);
            } else {
                $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
                if (in_array($ext, $allowedExtensions)) {
                    $stat = stat($fullPath);
                    $files[] = [
                        'id' => md5($relativePath),
                        'name' => $item,
                        'path' => $relativePath,
                        'url' => $baseUrl . $relativePath,
                        'type' => 'image',
                        'size' => formatFileSize($stat['size']),
                        'sizeBytes' => $stat['size'],
                        'uploadedAt' => date('Y-m-d', $stat['mtime']),
                        'extension' => $ext
                    ];
                }
            }
        }
    }
    
    scanDirectory($uploadsDir, $baseUrl, $allowedExtensions, $files);
    
    // Sort by upload date descending
    usort($files, function($a, $b) {
        return strtotime($b['uploadedAt']) - strtotime($a['uploadedAt']);
    });
}

echo json_encode([
    'success' => true,
    'files' => $files,
    'count' => count($files),
    'source' => $source
]);
?>
