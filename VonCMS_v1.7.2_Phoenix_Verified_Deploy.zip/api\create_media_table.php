<?php
/**
 * VonCMS - Create Media Table Migration
 * Run this once to create the media table for existing installations
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

if (!isset($pdo) || $pdo === null) {
    echo json_encode(['success' => false, 'message' => 'Database not configured']);
    exit();
}

try {
    // Create media table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS media (
        id INT AUTO_INCREMENT PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        filepath VARCHAR(255) NOT NULL,
        filetype VARCHAR(50),
        filesize INT,
        uploaded_by INT,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    
    echo json_encode([
        'success' => true, 
        'message' => 'Media table created successfully!'
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Failed to create table: ' . $e->getMessage()
    ]);
}
?>
