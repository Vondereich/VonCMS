<?php
/**
 * Dynamic Sitemap Generator
 * Generates XML sitemap from database content
 */

require_once '../von_config.php';

header("Content-Type: application/xml; charset=utf-8");

// Determine Base URL
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'];
$scriptDir = dirname(dirname($_SERVER['SCRIPT_NAME'])); // Helper to get root directory
$autoBaseUrl = rtrim($protocol . $host . $scriptDir, '/\\');

// Try to get site_url from settings
$baseUrl = $autoBaseUrl;
if (isset($pdo)) {
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM settings WHERE setting_key = 'site_url' AND setting_group = 'general'");
        $stmt->execute();
        $settingUrl = $stmt->fetchColumn();
        if (!empty($settingUrl)) {
            $baseUrl = rtrim($settingUrl, '/');
        }
    } catch (Exception $e) {}
}

// Initialize XML
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo "\n";
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo $baseUrl; ?>/</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>

<?php
try {
    if (isset($pdo)) {
        // Posts
        $stmt = $pdo->query("SELECT slug, updated_at FROM posts WHERE status = 'published' ORDER BY updated_at DESC");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $lastMod = date('c', strtotime($row['updated_at']));
            echo "    <url>\n";
            echo "        <loc>" . $baseUrl . "/post/" . htmlspecialchars($row['slug']) . "</loc>\n";
            echo "        <lastmod>" . $lastMod . "</lastmod>\n";
            echo "        <changefreq>weekly</changefreq>\n";
            echo "        <priority>0.8</priority>\n";
            echo "    </url>\n";
        }

        // Pages
        $stmtPages = $pdo->query("SELECT slug, updated_at FROM pages WHERE status = 'published' ORDER BY updated_at DESC");
        while ($row = $stmtPages->fetch(PDO::FETCH_ASSOC)) {
            $lastMod = date('c', strtotime($row['updated_at']));
            echo "    <url>\n";
            echo "        <loc>" . $baseUrl . "/page/" . htmlspecialchars($row['slug']) . "</loc>\n";
            echo "        <lastmod>" . $lastMod . "</lastmod>\n";
            echo "        <changefreq>monthly</changefreq>\n";
            echo "        <priority>0.5</priority>\n";
            echo "    </url>\n";
        }
    }
} catch (PDOException $e) {
    // Fail silently in XML or maintain partial sitemap
}
?>
</urlset>
