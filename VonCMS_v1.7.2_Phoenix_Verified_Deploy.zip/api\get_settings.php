<?php
/**
 * VonCMS - Get Settings API (Database Version)
 * SECURITY: Filters sensitive settings based on user role
 */

$configFile = '../von_config.php';
if (!file_exists($configFile)) {
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *'); 
    echo json_encode(['installed' => false]);
    exit();
}
require_once $configFile;

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Check if user is authenticated (for sensitive settings)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$isAdmin = isset($_SESSION['user']) && strtolower($_SESSION['user']['role'] ?? '') === 'admin';

try {
    // Build query based on user role
    if ($isAdmin) {
        // Admin gets ALL settings
        $stmt = $pdo->query("SELECT setting_group, setting_key, setting_value, setting_type FROM settings ORDER BY setting_group, setting_key");
    } else {
        // Public users only get non-sensitive settings
        $stmt = $pdo->query("SELECT setting_group, setting_key, setting_value, setting_type FROM settings WHERE is_public = 1 ORDER BY setting_group, setting_key");
    }
    
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Reconstruct settings object
    $settings = [];
    
    foreach ($rows as $row) {
        $group = $row['setting_group'];
        $key = $row['setting_key'];
        $value = $row['setting_value'];
        $type = $row['setting_type'];
        
        // Parse value based on type
        if ($type === 'json') {
            $value = json_decode($value, true);
        } elseif ($type === 'number') {
            $value = is_numeric($value) ? (int)$value : $value;
        } elseif ($type === 'boolean') {
            $value = $value === 'true' || $value === '1';
        }
        
        // Map to original structure for backward compatibility
        switch ($group) {
            case 'general':
                // Handle special keys explicitly
                if ($key === 'permalink_structure') {
                    $settings['permalinkStructure'] = $value;
                } elseif ($key === 'admin_profile') {
                    $settings['adminProfile'] = $value;
                } else {
                    // Auto-convert snake_case to camelCase for other keys
                    $settings[str_replace('_', '', ucwords($key, '_'))] = $value;
                    $settings[lcfirst(str_replace('_', '', ucwords($key, '_')))] = $value;
                }
                break;
            case 'seo':
                if ($key === 'analytics') {
                    $settings['api'] = $value;
                } elseif ($key === 'site_config') {
                    $settings['seo'] = $value;
                }
                break;
            case 'ads':
                if ($key === 'configuration') {
                    $settings['ads'] = $value;
                }
                break;
            case 'theme':
                if ($key === 'active_theme_id') {
                    $settings['activeThemeId'] = $value;
                } elseif ($key === 'customization') {
                    $settings['theme'] = $value;
                }
                break;
            case 'media':
                if (!isset($settings['media'])) {
                    $settings['media'] = [];
                }
                // Handle snake_case to camelCase for default_view
                if ($key === 'default_view') {
                    $settings['media']['defaultView'] = $value;
                } else {
                    $settings['media'][$key] = $value;
                }
                break;
            case 'navigation':
                if ($key === 'menu_items') {
                    $settings['navigation'] = $value;
                }
                break;
            case 'sidebar':
                if ($key === 'layout') {
                    $settings['sidebarLayout'] = $value;
                }
                break;
            case 'content':
                if ($key === 'categories') {
                    $settings['categories'] = $value;
                }
                break;
            case 'plugins':
                if ($key === 'active_plugins') {
                    $settings['activePlugins'] = $value;
                } elseif ($key === 'custom_plugins') {
                    $settings['customPlugins'] = $value;
                } elseif ($key === 'plugin_config') {
                    $settings['pluginConfig'] = $value;
                }
                break;
            case 'smtp':
                // Map SMTP settings directly to root level
                $settings[$key] = $value;
                break;
            case 'share':
                if ($key === 'templates') {
                    $settings['shareTemplates'] = $value;
                } else {
                    $settings[$key] = $value;
                }
                break;
        }
    }
    
    // Add metadata
    $settings['_source'] = 'database';
    $settings['_access_level'] = $isAdmin ? 'admin' : 'public';
    
    echo json_encode($settings);
    
} catch (PDOException $e) {
    // Fallback to JSON file if database fails
    $settingsFile = __DIR__ . '/../data/site_settings.json';
    
    if (file_exists($settingsFile)) {
        $jsonSettings = json_decode(file_get_contents($settingsFile), true);
        $jsonSettings['_source'] = 'json_fallback';
        $jsonSettings['_warning'] = 'Database unavailable, using JSON fallback';
        echo json_encode($jsonSettings);
    } else {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Settings unavailable',
            'db_error' => $e->getMessage()
        ]);
    }
}
?>
