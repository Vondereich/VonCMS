<?php
/**
 * VonCMS - Save Post API
 * Creates or updates a post in the database
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['title'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Title is required']);
    exit();
}

// Sanitize input - but preserve fields that shouldn't be HTML encoded
$rawContent = $input['content'] ?? '';
$rawTitle = $input['title'] ?? '';
$rawSlug = $input['slug'] ?? '';

if (function_exists('sanitize_input')) {
    $input = sanitize_input($input);
}

// Restore raw values (don't HTML-encode these)
$input['content'] = $rawContent;
$input['title'] = $rawTitle;

// Generate slug if not provided (use raw title)
if (empty($rawSlug)) {
    $input['slug'] = preg_replace('/[^a-z0-9]+/', '-', strtolower($rawTitle));
    $input['slug'] = trim($input['slug'], '-');
} else {
    $input['slug'] = $rawSlug;
}

// Handle image field (frontend uses 'image', database uses 'image_url')
$featuredImage = $input['image'] ?? $input['featured_image'] ?? $input['image_url'] ?? '';

// Auto-detect first image from content if no featured image provided
if (empty($featuredImage) && !empty($rawContent)) {
    // Match first img src in content
    if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/', $rawContent, $matches)) {
        $featuredImage = $matches[1];
    }
}

// Auto-generate excerpt from content if not provided
$excerpt = $input['excerpt'] ?? '';
if (empty(trim($excerpt)) && !empty($rawContent)) {
    // Strip HTML tags and get first 160 characters
    $plainText = strip_tags($rawContent);
    $plainText = preg_replace('/\s+/', ' ', $plainText); // Normalize whitespace
    $excerpt = trim(substr($plainText, 0, 160));
    if (strlen($plainText) > 160) {
        $excerpt .= '...';
    }
}

try {
    // Check if database connection exists
    if (!isset($pdo)) {
        echo json_encode(['success' => false, 'message' => 'Database not configured']);
        exit();
    }

    // Check if this is an update (has numeric ID) or insert (no ID or temp ID)
    $postId = $input['id'] ?? null;
    $isUpdate = $postId && is_numeric($postId);

    // Get category (default to Uncategorized if not provided)
    $category = $input['category'] ?? 'Uncategorized';

    // Get meta description
    $metaDescription = $input['metaDescription'] ?? $input['meta_description'] ?? '';

    if ($isUpdate) {
        // Update existing post
        $stmt = $pdo->prepare("UPDATE posts SET 
            title = :title, 
            slug = :slug, 
            content = :content, 
            excerpt = :excerpt, 
            status = :status, 
            image_url = :image_url,
            keywords = :keywords,
            category = :category,
            meta_description = :meta_description,
            updated_at = NOW()
        WHERE id = :id");
        
        $stmt->execute([
            'title' => $input['title'],
            'slug' => $input['slug'],
            'content' => $input['content'] ?? '',
            'excerpt' => $excerpt,
            'status' => $input['status'] ?? 'draft',
            'image_url' => $featuredImage,
            'keywords' => $input['keywords'] ?? '',
            'category' => $category,
            'meta_description' => $metaDescription,
            'id' => $postId
        ]);
        
        echo json_encode([
            'success' => true, 
            'message' => 'Post updated',
            'id' => (string)$postId,
            'slug' => $input['slug'],
            'image' => $featuredImage,
            'category' => $category
        ]);
    } else {
        // Insert new post
        $stmt = $pdo->prepare("INSERT INTO posts 
            (title, slug, content, excerpt, status, image_url, keywords, category, meta_description, author_id, created_at, updated_at) 
            VALUES 
            (:title, :slug, :content, :excerpt, :status, :image_url, :keywords, :category, :meta_description, :author_id, NOW(), NOW())");
        
        $stmt->execute([
            'title' => $input['title'],
            'slug' => $input['slug'],
            'content' => $input['content'] ?? '',
            'excerpt' => $excerpt,
            'status' => $input['status'] ?? 'draft',
            'image_url' => $featuredImage,
            'keywords' => $input['keywords'] ?? '',
            'category' => $category,
            'meta_description' => $metaDescription,
            'author_id' => 1 // Default to admin
        ]);
        
        // Get the new ID
        $newId = $pdo->lastInsertId();
        
        echo json_encode([
            'success' => true, 
            'message' => 'Post created',
            'id' => (string)$newId,
            'slug' => $input['slug'],
            'image' => $featuredImage,
            'category' => $category
        ]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to save post: ' . $e->getMessage()]);
}
?>

