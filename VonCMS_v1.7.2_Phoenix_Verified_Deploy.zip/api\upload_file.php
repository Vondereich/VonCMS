<?php
/**
 * VonCMS - File Upload API
 * Uploads images to /uploads/ folder with optional folder structure
 * Also saves to media database table for persistence
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
// Note: CSRF check removed for upload - session validation is sufficient

if (!isset($_FILES['file'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'No file uploaded']);
    exit;
}

$file = $_FILES['file'];
$baseUploadDir = dirname(__DIR__) . '/uploads/';

// Check for folder structure preference (from POST data or default to year_month)
$folderStructure = $_POST['folderStructure'] ?? 'year_month';

// Determine upload directory based on folder structure setting
if ($folderStructure === 'year_month') {
    $year = date('Y');
    $month = date('m');
    $uploadDir = $baseUploadDir . $year . '/' . $month . '/';
    
    // Auto-detect base URL
    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    // dirname($scriptDir) gets us to /VonCMS/ (parent of api)
    $parentBase = dirname($scriptDir);
    // Fix backslashes for Windows
    $parentBase = str_replace('\\', '/', $parentBase);
    
    $urlPrefix = $parentBase . '/uploads/' . $year . '/' . $month . '/';
} else {
    // Flat structure
    $uploadDir = $baseUploadDir;
    
    // Auto-detect base URL (same logic as above)
    $scriptDir = dirname($_SERVER['SCRIPT_NAME']);
    $parentBase = dirname($scriptDir);
    $parentBase = str_replace('\\', '/', $parentBase);
    
    $urlPrefix = $parentBase . '/uploads/';
}

// Create uploads directory if it doesn't exist
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Validate file type
$allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/x-icon', 'image/svg+xml'];
if (!in_array($file['type'], $allowedTypes)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid file type. Only images are allowed.']);
    exit;
}

// Validate file size (max 10MB)
$maxSize = 10 * 1024 * 1024; // 10MB
if ($file['size'] > $maxSize) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'File too large. Maximum size is 10MB.']);
    exit;
}

// Generate unique filename (preserve original extension)
$extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$originalName = pathinfo($file['name'], PATHINFO_FILENAME);
// Sanitize original name
$safeName = preg_replace('/[^a-zA-Z0-9_-]/', '', $originalName);
$safeName = substr($safeName, 0, 50); // Limit length
$filename = $safeName . '_' . uniqid() . '.' . $extension;
$targetPath = $uploadDir . $filename;

if (move_uploaded_file($file['tmp_name'], $targetPath)) {
    // Get file size for response
    $size = filesize($targetPath);
    $sizeFormatted = $size >= 1048576 
        ? number_format($size / 1048576, 2) . ' MB' 
        : number_format($size / 1024, 2) . ' KB';
    
    // Build relative path for storage
    $relativePath = ($folderStructure === 'year_month') 
        ? date('Y') . '/' . date('m') . '/' . $filename 
        : $filename;
    
    // Save to database (if available)
    $mediaId = null;
    if (isset($pdo) && $pdo !== null) {
        try {
            // Check if media table exists
            $tableCheck = $pdo->query("SHOW TABLES LIKE 'media'");
            if ($tableCheck->rowCount() > 0) {
                $stmt = $pdo->prepare("INSERT INTO media (filename, filepath, filetype, filesize, uploaded_by) VALUES (:filename, :filepath, :filetype, :filesize, :user_id)");
                $stmt->execute([
                    'filename' => $file['name'],
                    'filepath' => 'uploads/' . $relativePath,
                    'filetype' => $file['type'],
                    'filesize' => $size,
                    'user_id' => 1 // Default to admin, TODO: get from session
                ]);
                $mediaId = $pdo->lastInsertId();
            }
        } catch (PDOException $e) {
            // Continue without database - file is already uploaded
        }
    }
    
    echo json_encode([
        'success' => true,
        'url' => $urlPrefix . $filename,
        'filename' => $filename,
        'path' => $relativePath,
        'size' => $sizeFormatted,
        'type' => 'image',
        'uploadedAt' => date('Y-m-d'),
        'id' => $mediaId
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']);
}
?>