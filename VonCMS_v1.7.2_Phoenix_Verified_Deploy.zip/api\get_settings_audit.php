<?php
/**
 * VonCMS - Settings Audit Log Viewer
 * View history of all settings changes
 * SECURITY: Admin-only access
 */

require_once '../von_config.php';

header('Content-Type: application/json');

// SECURITY: Check authentication
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Admin access required']);
    exit();
}

try {
    // Get filter parameters
    $settingId = isset($_GET['setting_id']) ? intval($_GET['setting_id']) : null;
    $settingKey = isset($_GET['setting_key']) ? $_GET['setting_key'] : null;
    $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 50;
    
    // Build query
    $sql = "SELECT 
                al.id,
                al.setting_id,
                al.setting_group,
                al.setting_key,
                al.old_value,
                al.new_value,
                al.change_type,
                al.changed_at,
                u.username as changed_by_username,
                al.ip_address,
                al.user_agent
            FROM settings_audit_log al
            LEFT JOIN users u ON al.changed_by = u.id
            WHERE 1=1";
    
    $params = [];
    
    if ($settingId) {
        $sql .= " AND al.setting_id = ?";
        $params[] = $settingId;
    }
    
    if ($settingKey) {
        $sql .= " AND al.setting_key = ?";
        $params[] = $settingKey;
    }
    
    $sql .= " ORDER BY al.changed_at DESC LIMIT ?";
    $params[] = $limit;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format output
    foreach ($logs as &$log) {
        // Truncate long values for display
        if (strlen($log['old_value']) > 200) {
            $log['old_value_preview'] = substr($log['old_value'], 0, 200) . '...';
        }
        if (strlen($log['new_value']) > 200) {
            $log['new_value_preview'] = substr($log['new_value'], 0, 200) . '...';
        }
    }
    
    echo json_encode([
        'success' => true,
        'logs' => $logs,
        'count' => count($logs)
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
