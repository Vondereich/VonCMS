<?php
/**
 * VonCMS - Database Import API
 * Imports SQL file to database
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-CSRF-TOKEN");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Database not configured']);
    exit();
}

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

// Check if user is admin
if (strtolower($_SESSION['user']['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Admin access required']);
    exit();
}

// Check for uploaded file
if (!isset($_FILES['sqlfile']) || $_FILES['sqlfile']['error'] !== UPLOAD_ERR_OK) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'No SQL file uploaded']);
    exit();
}

$file = $_FILES['sqlfile'];

// Validate file type
$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if ($ext !== 'sql') {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Only .sql files allowed']);
    exit();
}

// Max 50MB
if ($file['size'] > 50 * 1024 * 1024) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'File too large (max 50MB)']);
    exit();
}

try {
    // Read SQL content
    $sql = file_get_contents($file['tmp_name']);
    
    if (empty($sql)) {
        echo json_encode(['success' => false, 'message' => 'Empty SQL file']);
        exit();
    }
    
    // Split into statements (basic split by semicolon)
    // Note: This is a simple approach, complex SQL might need better parsing
    $statements = array_filter(array_map('trim', explode(';', $sql)));
    
    $executed = 0;
    $errors = [];
    
    // Disable foreign key checks during import
    $pdo->exec("SET FOREIGN_KEY_CHECKS=0");
    
    foreach ($statements as $statement) {
        if (empty($statement)) continue;
        
        // Skip comments
        if (strpos(trim($statement), '--') === 0) continue;
        if (strpos(trim($statement), '/*') === 0) continue;
        
        try {
            $pdo->exec($statement);
            $executed++;
        } catch (PDOException $e) {
            $errors[] = substr($statement, 0, 50) . '... : ' . $e->getMessage();
        }
    }
    
    // Re-enable foreign key checks
    $pdo->exec("SET FOREIGN_KEY_CHECKS=1");
    
    echo json_encode([
        'success' => true,
        'message' => "Import complete. Executed $executed statements.",
        'executed' => $executed,
        'errors' => count($errors) > 0 ? array_slice($errors, 0, 5) : null
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Import failed: ' . $e->getMessage()]);
}
?>
