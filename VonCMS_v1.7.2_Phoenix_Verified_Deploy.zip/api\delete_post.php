<?php
/**
 * VonCMS - Delete Post API
 * Deletes a post from the database
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

$input = json_decode(file_get_contents('php://input'), true);

$postId = $input['id'] ?? null;

if (!$postId || !is_numeric($postId)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Valid post ID is required']);
    exit();
}

try {
    if (!isset($pdo)) {
        echo json_encode(['success' => false, 'message' => 'Database not configured']);
        exit();
    }

    // Delete the post
    $stmt = $pdo->prepare("DELETE FROM posts WHERE id = :id");
    $stmt->execute(['id' => $postId]);
    
    $rowsAffected = $stmt->rowCount();
    
    if ($rowsAffected > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Post deleted',
            'id' => (string)$postId
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Post not found'
        ]);
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Failed to delete post: ' . $e->getMessage()]);
}
?>
