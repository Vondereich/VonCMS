<?php
/**
 * VonCMS - Database Backup API
 * Generates SQL dump of all tables for download
 */

// Don't set JSON header - we'll be sending SQL file
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-CSRF-TOKEN");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Load database connection
require_once '../von_config.php';

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
// Note: CSRF check removed for backup download - admin session validation is sufficient

// Check if user is admin
if (strtolower($_SESSION['user']['role'] ?? '') !== 'admin') {
    header('Content-Type: application/json');
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Admin access required']);
    exit();
}

try {
    // Get all tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    
    if (empty($tables)) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'No tables found']);
        exit();
    }
    
    // Generate backup filename
    $dbName = 'voncms';
    $timestamp = date('Y-m-d_His');
    $filename = "backup_{$dbName}_{$timestamp}.sql";
    
    // Set headers for file download
    header('Content-Type: application/sql');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    
    // SQL header
    echo "-- VonCMS Database Backup\n";
    echo "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    echo "-- Server: " . ($_SERVER['HTTP_HOST'] ?? 'localhost') . "\n";
    echo "-- Tables: " . count($tables) . "\n";
    echo "-- --------------------------------------------------------\n\n";
    echo "SET FOREIGN_KEY_CHECKS=0;\n\n";
    
    foreach ($tables as $table) {
        // Get CREATE TABLE statement
        $createStmt = $pdo->query("SHOW CREATE TABLE `$table`")->fetch();
        
        echo "-- \n";
        echo "-- Table structure: `$table`\n";
        echo "-- \n";
        echo "DROP TABLE IF EXISTS `$table`;\n";
        echo $createStmt['Create Table'] . ";\n\n";
        
        // Get data
        $rows = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        
        if (!empty($rows)) {
            echo "-- \n";
            echo "-- Data for table: `$table` (" . count($rows) . " rows)\n";
            echo "-- \n";
            
            foreach ($rows as $row) {
                $columns = array_keys($row);
                $values = array_map(function($v) use ($pdo) {
                    if ($v === null) return 'NULL';
                    return $pdo->quote($v);
                }, array_values($row));
                
                echo "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES (" . implode(', ', $values) . ");\n";
            }
            echo "\n";
        }
    }
    
    echo "SET FOREIGN_KEY_CHECKS=1;\n";
    echo "-- End of backup\n";
    
} catch (PDOException $e) {
    header('Content-Type: application/json');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Backup failed: ' . $e->getMessage()]);
}
?>
