<?php
/**
 * VonCMS - Settings Rollback API
 * Rollback a setting to a previous version from audit log
 * SECURITY: Admin-only access
 */

require_once '../von_config.php';

header('Content-Type: application/json');

// SECURITY: Check authentication
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Admin access required']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
$auditLogId = $input['audit_log_id'] ?? null;

if (!$auditLogId) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'audit_log_id required']);
    exit();
}

$userId = $_SESSION['user']['id'] ?? null;

try {
    $pdo->beginTransaction();
    
    // Get the audit log entry
    $stmt = $pdo->prepare("SELECT * FROM settings_audit_log WHERE id = ?");
    $stmt->execute([$auditLogId]);
    $auditEntry = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$auditEntry) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Audit log entry not found']);
        exit();
    }
    
    // Rollback to old_value
    $rollbackValue = $auditEntry['old_value'];
    $settingGroup = $auditEntry['setting_group'];
    $settingKey = $auditEntry['setting_key'];
    
    // Update the setting
    $updateStmt = $pdo->prepare("
        UPDATE settings 
        SET setting_value = ?, 
            updated_by = ?,
            version = version + 1
        WHERE setting_group = ? AND setting_key = ?
    ");
    
    $updateStmt->execute([$rollbackValue, $userId, $settingGroup, $settingKey]);
    
    if ($updateStmt->rowCount() === 0) {
        $pdo->rollBack();
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Setting not found']);
        exit();
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'Setting rolled back successfully',
        'setting_group' => $settingGroup,
        'setting_key' => $settingKey,
        'rolled_back_to' => $rollbackValue
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
