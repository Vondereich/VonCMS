<?php
/**
 * VonCMS - Get Single Post API
 * Fetch a single post by ID or slug
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';

// Get ID or slug from query params
$id = $_GET['id'] ?? null;
$slug = $_GET['slug'] ?? null;

if (!$id && !$slug) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID or slug required']);
    exit();
}

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Database not configured']);
    exit();
}

try {
    if ($id) {
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE id = ?");
        $stmt->execute([$id]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM posts WHERE slug = ?");
        $stmt->execute([$slug]);
    }
    
    $post = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$post) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Post not found']);
        exit();
    }
    
    // Increment view count
    $pdo->prepare("UPDATE posts SET views = views + 1 WHERE id = ?")->execute([$post['id']]);
    
    // Get author info if exists
    if ($post['author_id']) {
        $authorStmt = $pdo->prepare("SELECT id, username, avatar FROM users WHERE id = ?");
        $authorStmt->execute([$post['author_id']]);
        $post['author'] = $authorStmt->fetch(PDO::FETCH_ASSOC);
    }
    
    echo json_encode([
        'success' => true,
        'post' => $post
    ]);
    
} catch (PDOException $e) {
    error_log("get_post error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>