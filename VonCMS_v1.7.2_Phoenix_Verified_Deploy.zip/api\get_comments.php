<?php
/**
 * VonCMS - Get Comments API
 * Returns all comments from database
 */
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../von_config.php';

// Check database connection
if (!isset($pdo) || $pdo === null) {
    // Fallback to JSON if database not configured
    $dataDir = __DIR__ . '/../data';
    $commentsFile = $dataDir . '/comments.json';
    
    $comments = [];
    if (file_exists($commentsFile)) {
        $content = file_get_contents($commentsFile);
        $data = json_decode($content, true);
        if (is_array($data)) {
            $comments = isset($data['comments']) ? $data['comments'] : $data;
        }
    }
    echo json_encode(['comments' => $comments, 'success' => true, 'source' => 'json']);
    exit();
}

try {
    // Get post_id filter if provided
    $postId = isset($_GET['post_id']) ? intval($_GET['post_id']) : null;
    $flat = isset($_GET['flat']) && $_GET['flat'] === 'true';
    
    // 1. Fetch ALL comments for the tree or list
    $query = "SELECT c.id, c.post_id AS postId, c.user_id AS userId, c.parent_id AS parentId, 
                     c.user_name AS username, c.user_avatar AS userAvatar, c.content, c.likes, c.status, 
                     c.created_at AS createdAt
              FROM comments c";
    
    $params = [];
    if ($postId) {
        $query .= " WHERE c.post_id = ?";
        $params[] = $postId;
    }
    $query .= " ORDER BY c.created_at ASC"; // ASC for tree building
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $allComments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 2. Process comments into a lookup map
    $commentMap = [];
    foreach ($allComments as $c) {
        $id = $c['id'];
        $commentMap[$id] = [
            'id' => ($c['parentId'] ? 'r-' : 'c-') . $id,
            'dbId' => $id,
            'postId' => (string)$c['postId'],
            'userId' => $c['userId'],
            'parentId' => $c['parentId'],
            'username' => $c['username'],
            'userAvatar' => $c['userAvatar'],
            'content' => html_entity_decode($c['content'], ENT_QUOTES, 'UTF-8'),
            'likes' => (int)$c['likes'],
            'status' => $c['status'] ?? 'approved',
            'createdAt' => $c['createdAt'],
            'replies' => []
        ];
    }

    // 3. Build Tree or return Flat list
    if ($flat && !$postId) {
        // For admin dashboard flat view if requested, or just return map
        echo json_encode(['comments' => array_values($commentMap), 'success' => true, 'source' => 'database']);
        exit();
    }

    $tree = [];
    foreach ($commentMap as $id => &$comment) {
        if ($comment['parentId'] && isset($commentMap[$comment['parentId']])) {
            $commentMap[$comment['parentId']]['replies'][] = &$comment;
        } else {
            // It's a root comment for this view
            $tree[] = &$comment;
        }
    }

    // If viewing specific post, usually we want root comments with nested replies.
    // If viewing general admin list, the user said "dia tulis satu je, patut kalau ada nested, dia keluar semua".
    // If no postId provided and no flat flag, returning the tree will show top-level chains.
    
    echo json_encode(['comments' => array_values($tree), 'success' => true, 'source' => 'database']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
