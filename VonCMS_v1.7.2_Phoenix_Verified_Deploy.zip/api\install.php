<?php
header('Content-Type: application/json');

// Security Check: If config already has a PDO connection and isn't a dummy, block re-install.
// For this simple version, we check if von_config.php has real content or we can check a flag.
// A robust way is to check if 'von_config.php' is writable or if a lock file exists.
$configFile = '../von_config.php';

if (file_exists($configFile)) {
    include $configFile;
    if (isset($pdo) && $pdo !== null) {
        // Already installed
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'System is already installed.']);
        exit();
    }
}

// 1. Validate Input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    echo json_encode(['success' => false, 'message' => 'No data received.']);
    exit();
}

$dbHost = $input['dbHost'] ?? 'localhost';
$dbName = $input['dbName'] ?? '';
$dbUser = $input['dbUser'] ?? '';
$dbPass = $input['dbPass'] ?? '';
$siteTitle = $input['siteTitle'] ?? 'My Website';
$adminUsername = $input['adminUsername'] ?? 'admin';
$adminEmail = $input['adminEmail'] ?? '';
$adminPass = $input['adminPass'] ?? '';

if (!$dbName || !$dbUser || !$adminUsername || !$adminEmail || !$adminPass) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Missing required fields.']);
    exit();
}

// Password strength validation
if (strlen($adminPass) < 8 || 
    !preg_match('/[A-Z]/', $adminPass) || 
    !preg_match('/[0-9]/', $adminPass) || 
    !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $adminPass)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters with uppercase letter, number, and special character (!@#$%^&*(),.?":{}|<>).']);
    exit();
}

// 2. Try DB Connection
try {
    $dsn = "mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4";
    $pdo = new PDO($dsn, $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database connection failed: ' . $e->getMessage()]);
    exit();
}

// 3. Create Tables (Complete Schema)
try {
    // Users Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(100) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(20) DEFAULT 'Member',
        avatar VARCHAR(255),
        bio TEXT,
        email_verified TINYINT(1) DEFAULT 0,
        verification_token VARCHAR(64) DEFAULT NULL,
        verification_token_expires DATETIME DEFAULT NULL,
        reset_token VARCHAR(64) DEFAULT NULL,
        reset_token_expires DATETIME DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Posts Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS posts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) NOT NULL UNIQUE,
        content LONGTEXT,
        excerpt TEXT,
        image_url VARCHAR(255),
        author VARCHAR(100),
        author_id INT,
        status VARCHAR(20) DEFAULT 'draft',
        category VARCHAR(100) DEFAULT 'Uncategorized',
        keywords VARCHAR(255),
        meta_description TEXT,
        views INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Pages Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS pages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(255) NOT NULL UNIQUE,
        content LONGTEXT,
        excerpt TEXT,
        author VARCHAR(100),
        author_id INT,
        status VARCHAR(20) DEFAULT 'draft',
        keywords VARCHAR(255),
        meta_description TEXT,
        views INT DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Comments/Discussions Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS comments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        post_id INT NOT NULL,
        parent_id INT DEFAULT NULL,
        user_id INT,
        user_name VARCHAR(100),
        user_avatar VARCHAR(255),
        content TEXT NOT NULL,
        likes INT DEFAULT 0,
        status VARCHAR(20) DEFAULT 'approved',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (post_id) REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (parent_id) REFERENCES comments(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Settings Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_group VARCHAR(50) NOT NULL,
        setting_key VARCHAR(100) NOT NULL,
        setting_value LONGTEXT,
        setting_type VARCHAR(20) DEFAULT 'string',
        version INT DEFAULT 1,
        is_sensitive BOOLEAN DEFAULT FALSE,
        is_public BOOLEAN DEFAULT TRUE,
        updated_by INT DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_group_key (setting_group, setting_key),
        INDEX idx_group (setting_group)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Media Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS media (
        id INT AUTO_INCREMENT PRIMARY KEY,
        filename VARCHAR(255) NOT NULL,
        filepath VARCHAR(255) NOT NULL,
        filetype VARCHAR(50),
        filesize INT,
        uploaded_by INT,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 4. Create Admin User
    $hashedPass = password_hash($adminPass, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (:username, :email, :pass, 'Admin')");
    $stmt->execute(['username' => $adminUsername, 'email' => $adminEmail, 'pass' => $hashedPass]);

    // 5. Insert Default Settings
    $defaultSettings = [
        ['general', 'site_name', $siteTitle, 'string'],
        ['general', 'site_description', 'A modern content management system', 'string'],
        ['general', 'site_tagline', 'Modern Content Management', 'string'],
        ['general', 'posts_per_page', '6', 'number'],
        ['general', 'discussion_enabled', 'true', 'boolean'],
        ['general', 'permalink_structure', 'slug', 'string'],
        ['theme', 'active_theme_id', 'theme-default', 'string'],
        ['theme', 'customization', '{"primaryColor":"#0ea5ff","fontFamily":"Inter, sans-serif","borderRadius":"0.5rem"}', 'json'],
        ['navigation', 'menu_items', '[{"id":"nav1","label":"Home","url":"home","type":"internal"}]', 'json'],
        ['sidebar', 'layout', '[{"id":"w1","type":"trending","title":"Trending Now","isVisible":true}]', 'json'],
        ['ads', 'configuration', '{"adsEnabled":false,"headerAd":"","sidebarAd":"","inFeedAd":"","popupAd":""}', 'json'],
        ['content', 'categories', '["Uncategorized","News","Updates"]', 'json'],
        ['plugins', 'active_plugins', '[]', 'json'],
        ['plugins', 'custom_plugins', '[]', 'json'],
        ['plugins', 'plugin_config', '{"vp_promo_bar":{"text":"Welcome to our site!","linkUrl":"#","linkText":"Learn More"},"vp_gift_widget":{"targetUrl":"#","tooltipText":"Claim Gift"}}', 'json'],
        ['share', 'share_placement', 'none', 'string']
    ];

    $settingsStmt = $pdo->prepare("INSERT INTO settings (setting_group, setting_key, setting_value, setting_type) VALUES (?, ?, ?, ?)");
    foreach ($defaultSettings as $setting) {
        $settingsStmt->execute($setting);
    }

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Schema creation failed: ' . $e->getMessage()]);
    exit();
}

// 5. Write Config File
$configContent = "<?php
// VonCMS Configuration
// Generated by Installer on " . date('Y-m-d H:i:s') . "

// Production Error Reporting (Security Enhancement)
if (php_sapi_name() !== 'cli') {
    \$isProduction = !in_array(\$_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1', 'localhost:8080']);
    if (\$isProduction) {
        error_reporting(0);
        ini_set('display_errors', '0');
    } else {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
    }
}

\$db_host = '" . addslashes($dbHost) . "';
\$db_name = '" . addslashes($dbName) . "';
\$db_user = '" . addslashes($dbUser) . "';
\$db_pass = '" . addslashes($dbPass) . "';

try {
    \$dsn = \"mysql:host=\$db_host;dbname=\$db_name;charset=utf8mb4\";
    \$pdo = new PDO(\$dsn, \$db_user, \$db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException \$e) {
    // In production, log this instead of showing details
    die('Database connection failed.');
}

// Helper functions
function check_auth() {
    // Implement session check here
    return true; 
}

function sanitize_input(\$data) {
    if (is_array(\$data)) {
        foreach (\$data as \$key => \$value) {
            \$data[\$key] = sanitize_input(\$value);
        }
    } else {
        \$data = trim(\$data);
        \$data = stripslashes(\$data);
        \$data = htmlspecialchars(\$data, ENT_QUOTES, 'UTF-8');
    }
    return \$data;
}
?>";

if (file_put_contents($configFile, $configContent)) {
     // Also update site_settings.json with the Site Title if possible, 
     // but currently that's handled by Node/PHP API separate from this config.
     // We will return success.
    // 6. Generate .htaccess with dynamic RewriteBase
    $scriptPath = dirname(dirname($_SERVER['SCRIPT_NAME']));
    $basePath = rtrim($scriptPath, '/\\') . '/';
    
    $htaccessContent = "<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase " . $basePath . "

  # HTTPS Enforcement (Production Security)
  RewriteCond %{HTTPS} off
  RewriteCond %{HTTP_HOST} !^localhost [NC]
  RewriteCond %{HTTP_HOST} !^127\\.0\\.0\\.1 [NC]
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [R=301,L]

  RewriteCond %{REQUEST_FILENAME} -f
  RewriteRule ^ - [L]
  RewriteCond %{REQUEST_FILENAME} -d
  RewriteRule ^ - [L]

  
  # API rewrites (Legacy support)
  RewriteCond %{REQUEST_URI} ^/api/post$
  RewriteRule ^api/post$ api/get_post.php [L,QSA]
  RewriteCond %{REQUEST_URI} ^/api/save_settings$
  RewriteCond %{REQUEST_URI} ^/api/save_settings$
  RewriteRule ^api/save_settings$ save_settings.php [L,QSA]
  
  # Dynamic Sitemap
  RewriteRule ^sitemap\.xml$ api/sitemap.php [L]

  # Fallback to index.php
  RewriteRule ^ index.php [L,QSA]
</IfModule>

# Security Headers (Production Enhancement)
<IfModule mod_headers.c>
  Header set X-Frame-Options \"SAMEORIGIN\"
  Header set X-Content-Type-Options \"nosniff\"
  Header set X-XSS-Protection \"1; mode=block\"
  Header set Referrer-Policy \"strict-origin-when-cross-origin\"
</IfModule>

# File Security
<FilesMatch \"^\..+\">
  Require all denied
</FilesMatch>";

    // Write .htaccess to parent directory (root where index.php is)
    file_put_contents('../.htaccess', $htaccessContent);

    echo json_encode(['success' => true, 'message' => 'Installation successful! Config written.']);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to write von_config.php. Check permissions.']);
}
?>
