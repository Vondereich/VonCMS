<?php
/**
 * VonCMS - Password Reset API
 * Handles password reset request and token verification
 */

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';
require_once '../security.php';
require_once 'mail_helper.php';

// Rate limit check
RateLimiter::requireNotLimited();

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? 'request'; // 'request' or 'reset'

// Check if database connection exists
if (!isset($pdo) || $pdo === null) {
    http_response_code(503);
    echo json_encode(['success' => false, 'message' => 'Database not configured']);
    exit();
}

// Auto-migration: Add reset token columns if not exist
try {
    $columns = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('reset_token', $columns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN reset_token VARCHAR(64) DEFAULT NULL");
    }
    if (!in_array('reset_token_expires', $columns)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN reset_token_expires DATETIME DEFAULT NULL");
    }
} catch (PDOException $e) {
    error_log("Migration check: " . $e->getMessage());
}

if ($action === 'request') {
    // REQUEST PASSWORD RESET
    $email = trim($input['email'] ?? '');
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Valid email required']);
        exit();
    }
    
    try {
        // Find user by email
        $stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Always return success to prevent email enumeration
        if (!$user) {
            echo json_encode(['success' => true, 'message' => 'If this email exists, a reset link has been sent.']);
            exit();
        }
        
        // Generate reset token
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        // Store token
        $stmt = $pdo->prepare("UPDATE users SET reset_token = ?, reset_token_expires = ? WHERE id = ?");
        $stmt->execute([$token, $expires, $user['id']]);
        
        // Build reset URL
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $basePath = dirname(dirname($_SERVER['REQUEST_URI']));
        $resetUrl = "$protocol://$host$basePath?reset_token=$token";
        
        // Send email
        $subject = "Password Reset - VonCMS";
        $htmlBody = '
        <!DOCTYPE html>
        <html>
        <head><meta charset="UTF-8"></head>
        <body style="font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px;">
            <div style="max-width: 500px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">
                <div style="background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); padding: 30px; text-align: center;">
                    <h1 style="color: white; margin: 0; font-size: 24px;">🔐 Password Reset</h1>
                </div>
                <div style="padding: 30px;">
                    <p style="color: #333; font-size: 16px;">Hi <strong>' . htmlspecialchars($user['username']) . '</strong>,</p>
                    <p style="color: #666;">You requested a password reset. Click the button below to set a new password:</p>
                    <div style="text-align: center; margin: 30px 0;">
                        <a href="' . $resetUrl . '" style="display: inline-block; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 15px 40px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 16px;">Reset Password</a>
                    </div>
                    <p style="color: #999; font-size: 12px;">This link expires in 1 hour. If you didn\'t request this, ignore this email.</p>
                </div>
            </div>
        </body>
        </html>';
        
        vonSendMail($email, $subject, $htmlBody);
        
        echo json_encode(['success' => true, 'message' => 'If this email exists, a reset link has been sent.']);
        
    } catch (PDOException $e) {
        error_log("Password reset request error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Request failed']);
    }
    
} elseif ($action === 'reset') {
    // RESET PASSWORD WITH TOKEN
    $token = $input['token'] ?? '';
    $newPassword = $input['password'] ?? '';
    
    if (strlen($token) !== 64) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid token']);
        exit();
    }
    
    // Password strength validation
    if (strlen($newPassword) < 8 || 
        !preg_match('/[A-Z]/', $newPassword) || 
        !preg_match('/[0-9]/', $newPassword) || 
        !preg_match('/[!@#$%^&*(),.?":{}|<>]/', $newPassword)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Password must be at least 8 characters with uppercase letter, number, and special character']);
        exit();
    }
    
    try {
        // Find user with valid token
        $stmt = $pdo->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_token_expires > NOW()");
        $stmt->execute([$token]);
        $user = $stmt->fetch();
        
        if (!$user) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
            exit();
        }
        
        // Update password
        $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_token_expires = NULL WHERE id = ?");
        $stmt->execute([$hashedPassword, $user['id']]);
        
        echo json_encode(['success' => true, 'message' => 'Password updated successfully. You can now log in.']);
        
    } catch (PDOException $e) {
        error_log("Password reset error: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Reset failed']);
    }
    
} else {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid action']);
}
?>