<?php
/**
 * VonCMS - Get Pages API
 */
require_once '../von_config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

try {
    if (!isset($pdo)) {
        echo json_encode([]);
        exit();
    }

    $stmt = $pdo->query("SELECT id, title, slug, content, excerpt, status, keywords, meta_description, created_at, updated_at FROM pages ORDER BY created_at DESC");
    $pages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Transform for frontend compatibility (Page interface)
    $result = array_map(function($page) {
        return [
            'id' => (string)$page['id'],
            'title' => $page['title'] ?? '',
            'slug' => $page['slug'] ?? '',
            'content' => $page['content'] ?? '',
            'excerpt' => $page['excerpt'] ?? '',
            'status' => $page['status'] ?? 'draft',
            'keywords' => $page['keywords'] ?? '',
            'metaDescription' => $page['meta_description'] ?? '',
            'updatedAt' => $page['updated_at'] ?? $page['created_at'] ?? date('Y-m-d H:i:s'),
            'author' => 'Admin'
        ];
    }, $pages);
    
    echo json_encode($result);
} catch (PDOException $e) {
    echo json_encode([]);
}
?>
