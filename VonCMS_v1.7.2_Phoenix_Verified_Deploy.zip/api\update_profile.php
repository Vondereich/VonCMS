<?php
/**
 * VonCMS - Update Profile API
 * Updates user bio and avatar from profile page
 */
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Load database connection
require_once '../von_config.php';

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
// Note: CSRF check removed for profile update - session validation is sufficient

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid input or missing user ID']);
    exit();
}

// Authorization: Only allow updating self OR if current user is admin
$currentUser = $_SESSION['user'];
if ($currentUser['id'] != $input['id'] && strtolower($currentUser['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized to update this profile']);
    exit();
}

// Check database connection
if (!isset($pdo) || $pdo === null) {
    http_response_code(503);
    echo json_encode(['success' => false, 'error' => 'Database not configured']);
    exit();
}

try {
    $userId = $input['id'];
    $bio = $input['bio'] ?? '';
    $avatar = $input['avatar'] ?? '';

    // Update user in database
    $stmt = $pdo->prepare("UPDATE users SET bio = ?, avatar = ? WHERE id = ?");
    $result = $stmt->execute([$bio, $avatar, $userId]);

    if ($result) {
        // Update session if updating own profile
        if ($currentUser['id'] == $userId) {
            $_SESSION['user']['bio'] = $bio;
            $_SESSION['user']['avatar'] = $avatar;
        }
        
        echo json_encode([
            'success' => true, 
            'message' => 'Profile updated successfully',
            'user' => [
                'bio' => $bio,
                'avatar' => $avatar
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Failed to update database']);
    }

} catch (PDOException $e) {
    error_log("Update profile error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Database error: ' . $e->getMessage()]);
}
?>
