<?php
/**
 * Check Auth API - Verify if user has valid session
 * Returns user data if logged in, or error if not
 */

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, X-CSRF-TOKEN");
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

require_once '../von_config.php';
require_once '../security.php';

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and session is valid
if (isset($_SESSION['user']) && SessionManager::isValid()) {
    // Touch session to extend expiry
    SessionManager::touch();
    
    // Return user data
    echo json_encode([
        'success' => true,
        'authenticated' => true,
        'user' => $_SESSION['user']
    ]);
} else {
    // No valid session
    http_response_code(200); // Still 200, just not authenticated
    echo json_encode([
        'success' => true,
        'authenticated' => false,
        'user' => null
    ]);
}
?>