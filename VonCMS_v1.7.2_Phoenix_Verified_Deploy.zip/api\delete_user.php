<?php
require_once '../von_config.php';

// Enforce Security
require_once '../security.php';
SessionManager::requireValidSession();
CSRFProtection::requireToken();

// Check if user is admin
if (strtolower($_SESSION['user']['role'] ?? '') !== 'admin') {
    http_response_code(403);
    echo json_encode(['error' => 'Admin access required']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'User ID is required']);
    exit();
}

$id = $input['id'];

// Protect Root Admin (ID 1)
if ($id == 1) {
     http_response_code(403);
    echo json_encode(['error' => 'Cannot delete root admin']);
    exit();
}

try {
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
    $stmt->execute(['id' => $id]);
    
    echo json_encode(['success' => true, 'message' => 'User deleted']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Failed to delete user: ' . $e->getMessage()]);
}
?>
